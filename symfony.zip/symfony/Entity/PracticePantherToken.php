<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Class PracticePantherToken
 * @package AppBundle\Entity
 *
 * @ORM\Entity(repositoryClass="AppBundle\Repository\PracticePantherTokenRepository")
 * @ORM\Table(name="practice_panther_token")
 */
class PracticePantherToken
{
    const TOKEN_TYPE            = 'bearer';

    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var User
     *
     * @ORM\ManyToOne(targetEntity="User")
     * @ORM\JoinColumn(name="user", referencedColumnName="id")
     */
    private $user;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=1000)
     */
    private $accessToken;

    /**
     * @var \DateTime;
     *
     * @ORM\Column(type="datetime")
     */
    private $accessTokenExpiry;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=100)
     */
    private $refreshToken;

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set accessToken.
     *
     * @param string $accessToken
     *
     * @return PracticePantherToken
     */
    public function setAccessToken($accessToken)
    {
        $this->accessToken = $accessToken;

        return $this;
    }

    /**
     * Get accessToken.
     *
     * @return string
     */
    public function getAccessToken()
    {
        return $this->accessToken;
    }

    /**
     * Set accessTokenExpiry.
     *
     * @param \DateTime $accessTokenExpiry
     *
     * @return PracticePantherToken
     */
    public function setAccessTokenExpiry($accessTokenExpiry)
    {
        $this->accessTokenExpiry = $accessTokenExpiry;

        return $this;
    }

    /**
     * Get accessTokenExpiry.
     *
     * @return \DateTime
     */
    public function getAccessTokenExpiry()
    {
        return $this->accessTokenExpiry;
    }

    /**
     * Set refreshToken.
     *
     * @param string $refreshToken
     *
     * @return PracticePantherToken
     */
    public function setRefreshToken($refreshToken)
    {
        $this->refreshToken = $refreshToken;

        return $this;
    }

    /**
     * Get refreshToken.
     *
     * @return string
     */
    public function getRefreshToken()
    {
        return $this->refreshToken;
    }

    /**
     * Set user.
     *
     * @param \AppBundle\Entity\User|null $user
     *
     * @return PracticePantherToken
     */
    public function setUser(\AppBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user.
     *
     * @return \AppBundle\Entity\User|null
     */
    public function getUser()
    {
        return $this->user;
    }
}
