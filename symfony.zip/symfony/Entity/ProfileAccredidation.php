<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Hateoas\Configuration\Annotation as Hateoas;
use JMS\Serializer\Annotation as Serializer;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class ProfileAccredidation
 * @package AppBundle\Entity
 *
 * @ORM\Entity(repositoryClass="AppBundle\Repository\ProfileAccredidationRepository")
 * @ORM\Table(name="profile_accredidation")
 */
class ProfileAccredidation
{
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @Serializer\Groups({"public"})
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\CompanyProfile")
     * @ORM\JoinColumn(name="company_profile_id", referencedColumnName="id")
     * @Serializer\Groups({"public"})
     */
    private $company_profile;

    /**
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\BranchProfile")
     * @ORM\JoinColumn(name="branch_profile_id", referencedColumnName="id")
     * @Serializer\Groups({"public"})
     */
    private $branch_profile;

    /**
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\UserProfile")
     * @ORM\JoinColumn(name="user_profile_id", referencedColumnName="id")
     * @Serializer\Groups({"public"})
     */
    private $user_profile;

    /**
     * @ORM\Column(type="string", length=100, nullable=false)
     * @Serializer\Groups({"public"})
     * @Assert\NotBlank(
     *     groups={
     *         "company_profile_post",
     *         "company_profile_put",
     *         "branch_profile_post",
     *         "branch_profile_put",
     *         "user_profile_post",
     *         "user_profile_put"
     *     }
     * )
     */
    private $logo;

    /**
     * @ORM\Column(type="string", length=100, nullable=true, options={"default": null})
     * @Serializer\Groups({"public"})
     * @Assert\Length(
     *     groups={
     *         "company_profile_post",
     *         "company_profile_put",
     *         "branch_profile_post",
     *         "branch_profile_put",
     *         "user_profile_post",
     *         "user_profile_put"
     *     },
     *     max="100"
     * )
     * @Assert\Url(
     *     groups={
     *         "company_profile_post",
     *         "company_profile_put",
     *         "branch_profile_post",
     *         "branch_profile_put",
     *         "user_profile_post",
     *         "user_profile_put"
     *     }
     * )
     */
    private $url;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set logo
     *
     * @param string $logo
     *
     * @return ProfileAccredidation
     */
    public function setLogo($logo)
    {
        $this->logo = $logo;

        return $this;
    }

    /**
     * Get logo
     *
     * @return string
     */
    public function getLogo()
    {
        return $this->logo;
    }

    /**
     * Set url
     *
     * @param string $url
     *
     * @return ProfileAccredidation
     */
    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * Get url
     *
     * @return string
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Set companyProfile
     *
     * @param \AppBundle\Entity\CompanyProfile $companyProfile
     *
     * @return ProfileAccredidation
     */
    public function setCompanyProfile(\AppBundle\Entity\CompanyProfile $companyProfile = null)
    {
        $this->company_profile = $companyProfile;

        return $this;
    }

    /**
     * Get companyProfile
     *
     * @return \AppBundle\Entity\CompanyProfile
     */
    public function getCompanyProfile()
    {
        return $this->company_profile;
    }

    /**
     * Set branchProfile
     *
     * @param \AppBundle\Entity\BranchProfile $branchProfile
     *
     * @return ProfileAccredidation
     */
    public function setBranchProfile(\AppBundle\Entity\BranchProfile $branchProfile = null)
    {
        $this->branch_profile = $branchProfile;

        return $this;
    }

    /**
     * Get branchProfile
     *
     * @return \AppBundle\Entity\BranchProfile
     */
    public function getBranchProfile()
    {
        return $this->branch_profile;
    }

    /**
     * Set userProfile
     *
     * @param \AppBundle\Entity\UserProfile $userProfile
     *
     * @return ProfileAccredidation
     */
    public function setUserProfile(\AppBundle\Entity\UserProfile $userProfile = null)
    {
        $this->user_profile = $userProfile;

        return $this;
    }

    /**
     * Get userProfile
     *
     * @return \AppBundle\Entity\UserProfile
     */
    public function getUserProfile()
    {
        return $this->user_profile;
    }
}
