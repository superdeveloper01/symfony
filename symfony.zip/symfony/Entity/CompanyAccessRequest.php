<?php

namespace AppBundle\Entity;

use AppBundle\Validator\Constraints as CustomConstraint;
use Doctrine\ORM\Mapping as ORM;
use Hateoas\Configuration\Annotation as Hateoas;
use JMS\Serializer\Annotation as Serializer;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class CompanyAccessRequest
 * @package AppBundle\Entity
 *
 * @ORM\Entity(repositoryClass="AppBundle\Repository\CompanyAccessRequestRepository")
 * @ORM\Table(name="company_access_request")
 * @Hateoas\Relation("self", href="expr('/company-access-request/' ~ object.getId())")
 */
class CompanyAccessRequest
{
    /**
     * @var integer
     *
     * @ORM\Column(type="integer", unique=true, nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @Serializer\Groups({"public"})
     * @Assert\Blank(
     *     groups={"put_company_access_request"}
     * )
     */
    private $id;

    /**
     * @var Branch
     *
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\Branch")
     * @ORM\JoinColumn(name="branch", referencedColumnName="id")
     * @Serializer\Groups({"public"})
     * @Assert\Valid()
     * @Assert\NotBlank(
     *     groups={"post_company_access_request"}
     * )
     * @CustomConstraint\IsEnterpriseBranchConstraint(
     *     groups={"post_company_access_request"}
     * )
     */
    private $branch;

    /**
     * @var User
     *
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\User")
     * @ORM\JoinColumn(name="access_requestor", referencedColumnName="id")
     * @Serializer\Groups({"public"})
     * @Assert\NotBlank(
     *     groups={"post_company_access_request"}
     * )
     * @CustomConstraint\UserDoesNotHaveBranchConstraintValidator(
     *     groups={"post_company_access_request"}
     * )
     */
    private $accessRequestor;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=false)
     * @Serializer\Groups({"public"})
     */
    private $accessRequestDate;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=false, options={"default": 100})
     * @Serializer\Groups({"public"})
     */
    private $accessRequestStatus;

    /**
     * @var User
     *
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\User")
     * @ORM\JoinColumn(name="approved_by", referencedColumnName="id")
     * @Serializer\Groups({"public"})
     */
    private $approvedBy;

    /**
     * @var User
     *
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\User")
     * @ORM\JoinColumn(name="denied_by", referencedColumnName="id")
     * @Serializer\Groups({"public"})
     */
    private $deniedBy;


    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set accessRequestDate.
     *
     * @param \DateTime $accessRequestDate
     *
     * @return CompanyAccessRequest
     */
    public function setAccessRequestDate($accessRequestDate)
    {
        $this->accessRequestDate = $accessRequestDate;

        return $this;
    }

    /**
     * Get accessRequestDate.
     *
     * @return \DateTime
     */
    public function getAccessRequestDate()
    {
        return $this->accessRequestDate;
    }

    /**
     * Set accessRequestStatus.
     *
     * @param int $accessRequestStatus
     *
     * @return CompanyAccessRequest
     */
    public function setAccessRequestStatus($accessRequestStatus)
    {
        $this->accessRequestStatus = $accessRequestStatus;

        return $this;
    }

    /**
     * Get accessRequestStatus.
     *
     * @return int
     */
    public function getAccessRequestStatus()
    {
        return $this->accessRequestStatus;
    }

    /**
     * Set branch.
     *
     * @param \AppBundle\Entity\Branch|null $branch
     *
     * @return CompanyAccessRequest
     */
    public function setBranch(Branch $branch = null)
    {
        $this->branch = $branch;

        return $this;
    }

    /**
     * Get branch.
     *
     * @return \AppBundle\Entity\Branch|null
     */
    public function getBranch()
    {
        return $this->branch;
    }

    /**
     * Set approvedBy.
     *
     * @param \AppBundle\Entity\User|null $approvedBy
     *
     * @return CompanyAccessRequest
     */
    public function setApprovedBy(User $approvedBy = null)
    {
        $this->approvedBy = $approvedBy;

        return $this;
    }

    /**
     * Get approvedBy.
     *
     * @return \AppBundle\Entity\User|null
     */
    public function getApprovedBy()
    {
        return $this->approvedBy;
    }

    /**
     * Set deniedBy.
     *
     * @param \AppBundle\Entity\User|null $deniedBy
     *
     * @return CompanyAccessRequest
     */
    public function setDeniedBy(User $deniedBy = null)
    {
        $this->deniedBy = $deniedBy;

        return $this;
    }

    /**
     * Get deniedBy.
     *
     * @return \AppBundle\Entity\User|null
     */
    public function getDeniedBy()
    {
        return $this->deniedBy;
    }

    /**
     * Set accessRequestor.
     *
     * @param \AppBundle\Entity\User|null $accessRequestor
     *
     * @return CompanyAccessRequest
     */
    public function setAccessRequestor(User $accessRequestor = null)
    {
        $this->accessRequestor = $accessRequestor;

        return $this;
    }

    /**
     * Get accessRequestor.
     *
     * @return \AppBundle\Entity\User|null
     */
    public function getAccessRequestor()
    {
        return $this->accessRequestor;
    }
}
