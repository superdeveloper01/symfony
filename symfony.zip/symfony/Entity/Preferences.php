<?php

namespace AppBundle\Entity;

use AppBundle\Validator\Constraints as CustomConstraint;
use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation as Serializer;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class Preferences
 * @package AppBundle\Entity
 *
 * @ORM\MappedSuperclass
 * @ORM\Entity(repositoryClass="AppBundle\Repository\PreferencesRepository")
 * @ORM\InheritanceType("JOINED")
 * @ORM\DiscriminatorColumn(name="type", type="string")
 * @ORM\DiscriminatorMap({
 *     "user" = "AppBundle\Entity\Preferences\UserPreferences",
 *     "branch" = "AppBundle\Entity\Preferences\BranchPreferences",
 *     "company" = "AppBundle\Entity\Preferences\CompanyPreferences"
 * })
 */
abstract class Preferences
{
    const TYPE_USER = 'user';
    const TYPE_BRANCH = 'branch';
    const TYPE_COMPANY = 'company';

    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @Serializer\Groups({"private"})
     */
    private $id;

    /**
     * @ORM\Column(type="simple_array", nullable=true, options={"default": null})
     * @Serializer\Groups({"private"})
     * @Assert\Type(
     *     type="array",
     *     groups={
     *          "user_preferences_put",
     *          "user_preferences_post",
     *          "branch_preferences_put",
     *          "branch_preferences_post",
     *          "company_preferences_put",
     *          "company_preferences_post"
     *     }
     * )
     * @Assert\All(
     *     groups={
     *          "user_preferences_put",
     *          "user_preferences_post",
     *          "branch_preferences_put",
     *          "branch_preferences_post",
     *          "company_preferences_put",
     *          "company_preferences_post"
     *     },
     *     {
     *          @Assert\Email(
     *              checkHost=true,
     *              checkMX=true
     *          ),
     *          @CustomConstraint\KickboxApprovedConstraint(
     *              message="We were unable to validate this address as a valid e-mail address"
     *          )
     *     }
     * )
     */
    private $endorsementResponseCcs;

    /**
     * @ORM\Column(type="integer", nullable=false, options={"default": 5})
     * @Serializer\Groups({"private"})
     * @Assert\Type(
     *     type="integer",
     *     groups={
     *          "user_preferences_put",
     *          "user_preferences_post",
     *          "branch_preferences_put",
     *          "branch_preferences_post",
     *          "company_preferences_put",
     *          "company_preferences_post"
     *     }
     * )
     * @Assert\NotNull(
     *     groups={
     *          "user_preferences_put",
     *          "user_preferences_post",
     *          "branch_preferences_put",
     *          "branch_preferences_post",
     *          "company_preferences_put",
     *          "company_preferences_post"
     *     }
     * )
     */
    private $endorsementsResponseCcCondition;

    /**
     * @var bool
     *
     * @ORM\Column(type="boolean", nullable=false, options={"default": true})
     * @Serializer\Groups({"private"})
     */
    private $includeExternalReviewsInFeeds;

    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set endorsementResponseCcs.
     *
     * @param array|null $endorsementResponseCcs
     *
     * @return Preferences
     */
    public function setEndorsementResponseCcs($endorsementResponseCcs = null)
    {
        $this->endorsementResponseCcs = $endorsementResponseCcs;

        return $this;
    }

    /**
     * Get endorsementResponseCcs.
     *
     * @return array|null
     */
    public function getEndorsementResponseCcs()
    {
        return $this->endorsementResponseCcs;
    }

    /**
     * Set endorsementsResponseCcCondition.
     *
     * @param int $endorsementsResponseCcCondition
     *
     * @return Preferences
     */
    public function setEndorsementsResponseCcCondition($endorsementsResponseCcCondition)
    {
        $this->endorsementsResponseCcCondition = $endorsementsResponseCcCondition;

        return $this;
    }

    /**
     * Get endorsementsResponseCcCondition.
     *
     * @return int
     */
    public function getEndorsementsResponseCcCondition()
    {
        return $this->endorsementsResponseCcCondition;
    }

    /**
     * Set includeExternalReviewsInFeeds.
     *
     * @param bool $includeExternalReviewsInFeeds
     *
     * @return Preferences
     */
    public function setIncludeExternalReviewsInFeeds($includeExternalReviewsInFeeds)
    {
        $this->includeExternalReviewsInFeeds = $includeExternalReviewsInFeeds;

        return $this;
    }

    /**
     * Get includeExternalReviewsInFeeds.
     *
     * @return bool
     */
    public function getIncludeExternalReviewsInFeeds()
    {
        return $this->includeExternalReviewsInFeeds;
    }
}
