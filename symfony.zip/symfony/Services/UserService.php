<?php

namespace AppBundle\Services;

use AppBundle\Entity\Branch;
use AppBundle\Entity\Company;
use AppBundle\Entity\FeedSetting;
use AppBundle\Entity\Reseller;
use AppBundle\Entity\Stripe\Plan;
use AppBundle\Entity\User;
use AppBundle\Entity\Wix\WixUser;
use AppBundle\Enumeration\FeatureAccessLevel;
use AppBundle\Enumeration\PayeeLevel;
use AppBundle\Repository\ResellerRepository;
use AppBundle\Repository\Stripe\PlanRepository;
use AppBundle\Repository\UserRepository;
use AppBundle\Utilities\SlugUtilities;
use Doctrine\ORM\EntityManager;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Security\Core\Authorization\AuthorizationChecker;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoder;

/**
 * Class UserService
 * @package AppBundle\Services
 */
class UserService
{
    const DEFAULT_MINIMUM_REVIEW_VALUE = .8;

    /** @var AuthorizationChecker $authChecker */
    private $authChecker;

    /** @var EntityManager $em */
    private $em;

    /** @var UserPasswordEncoder $encoder */
    private $encoder;

    /** @var ContainerInterface $container */
    private $container;

    /** @var CompanyService|object $companyService */
    private $companyService;

    /** @var BranchService|object $branchService */
    private $branchService;

    /** @var PlanService|object $planService */
    private $planService;

    /** @var StripeService|object $stripeService */
    private $stripeService;

    /** @var EndorsementResponseService|object $endorsementResponseService */
    private $endorsementResponseService;

    /** @var SurveyService|object $surveyService */
    private $surveyService;

    /** @var FeedService|object $feedService */
    private $feedService;

    /**
     * UserService constructor.
     * @param EntityManager       $em
     * @param UserPasswordEncoder $encoder
     */
    public function __construct(
        AuthorizationChecker $authChecker,
        EntityManager $em,
        UserPasswordEncoder $encoder,
        ContainerInterface $container
    ) {
        $this->authChecker = $authChecker;
        $this->em = $em;
        $this->encoder = $encoder;
        $this->container = $container;
        $this->companyService = $container->get('company_service');
        $this->branchService = $container->get('branch_service');
        $this->planService = $container->get('plan_service');
        $this->stripeService = $container->get('stripe_service');
        $this->endorsementResponseService = $container->get('endorsement_response_service');
        $this->surveyService = $container->get('survey_service');
        $this->feedService = $container->get('feed_service');
        $this->mailer = $container->get('mailer');
    }

    /**
     * @param mixed $user
     * @return bool
     */
    public function getIsAdmin($user)
    {
        if ($user instanceof User) {
            return (in_array('ROLE_ADMIN', $user->getRoles()) || in_array('ROLE_SUPER_ADMIN', $user->getRoles()));
        }

        return false;
    }

    /**
     * @param User   $user
     * @param bool   $isAdmin
     * @return User
     */
    public function createUser(User $user, $isAdmin)
    {
        $u = new User;
        $u->setUsername($user->getUsername());
        $u->setPassword($this->encoder->encodePassword($user, $user->getPlainPassword()));
        $u->setFirstName($user->getFirstName());
        $u->setLastName($user->getLastName());
        $u->setRoles(($isAdmin && null !== $user->getRoles()) ? $user->getRoles() : $this->getNewUserRoles($user));
        $u->setActive(true);
        $u->setCreated(new \DateTime);
        $u->setWelcomeSent(null);
        $u->setBranch($user->getBranch());
        $u->setSlug($this->getUserSlug($user));
        $u->setApiKey($this->generateUserApiKey());
        $u->setIsRepReviewsClient(false);
        $u->setStripeCouponId($user->getStripeCouponId());
        $u->setPartnerId($user->getPartnerId());

        if ($user->getBranch() && $user->getBranch()->getCompany()) {
            $company = (null != $user->getBranch()->getCompany()->getId()) ?
                $this->em->getReference(Company::class, $user->getBranch()->getCompany()->getId()) :
                $this->companyService->createCompany($user->getBranch()->getCompany());
        }

        if ($user->getBranch()) {
            if (null != $user->getBranch()->getId()) {
                $u->setBranch($this->em->getReference(Branch::class, $user->getBranch()->getId()));
            } else {
                if (isset($company)) {
                    $user->getBranch()->setCompany($company);
                }
                $branch = $this->branchService->createBranch($user->getBranch());
                $u->setBranch($branch);
            }
        }

        /**
         * Everyone starts with a free plan, except for bundled reseller accounts - they're automatically
         * entered into an premium plan
         */
        $this->setResellerAndPlan($user, $u);

        $this->em->persist($u);
        $this->em->flush();

        $this->container->get('survey_service')->createDefaultSurvey($u);

        return $u;
    }

    /**
     * @param User        $u
     * @param User        $user
     * @param bool        $isAdmin
     * @param null|string $password
     * @return User
     */
    public function updateUser(User $u, User $user, $isAdmin, $password = null)
    {
        $originalUserStatus = $u->getActive();

        $u->setUsername($user->getUsername());
        if (null !== $password) {
            $u->setPassword($this->encoder->encodePassword($u, $password));
        }
        $u->setFirstName($user->getFirstName());
        $u->setLastName($user->getLastName());
        if ($isAdmin) {
            $u->setRoles($user->getRoles());
        }
        $u->setActive($user->getActive());

        // check if branch information is being passed
        if (null !== $user->getBranch()) {
            $branch = $this->em->getReference('AppBundle:Branch', $user->getBranch()->getId());
            if ($branch) {
                $u->setBranch($branch);
            }
        }

        $this->em->flush();

        if ($originalUserStatus !== $user->getActive()) {
            $this->updateUserSubscription($user);
        }

        return $u;
    }

    /**
     * @param User $invitee
     * @param User $inviter
     * @return User
     */
    public function inviteUser(User $invitee, User $inviter)
    {
        $invitee->setPassword($this->encoder->encodePassword($invitee, md5(uniqid())));
        $invitee->setRoles(['ROLE_USER']);
        $invitee->setActive(true);
        $invitee->setCreated(new \DateTime);
        $invitee->setWelcomeSent(new \DateTime);
        $invitee->setBranch(
            $this->authChecker->isGranted('ROLE_COMPANY_ADMIN', $inviter) ?
                $this->em->getReference('AppBundle:Branch', $invitee->getBranch()->getId()) :
                $inviter->getBranch()
        );
        $invitee->setSlug($this->getUserSlug($invitee));
        $invitee->setApiKey($this->generateUserApiKey());
        $invitee->setIsRepReviewsClient($inviter->getIsRepReviewsClient());
        $invitee->setSecurityHash($this->getSecurityHash());
        $invitee->setSecurityHashExpiry(new \DateTime(date('Y-m-d H:i:s', strtotime('+14 days'))));

        // New user inherits the inviter's coupon
        $invitee->setStripeCouponId($inviter->getStripeCouponId());

        // New user inherits the inviter's reseller
        $invitee->setReseller($inviter->getReseller());

        // Set the plan for the invitee
        $invitee->setPlan($this->getInviteePlan($inviter->getBranch()->getCompany(), $invitee->getBranch()));

        // Save the new user
        $this->em->persist($invitee);
        $this->em->flush();

        // Update stripe subscriptions
        $this->updateInviteeSubscription($invitee);

        // Invite the new user
        $this->mailer->sendInvitation($invitee, $inviter, $this->getPasswordResetLink($invitee));

        $this->container->get('survey_service')->createDefaultSurvey($invitee);

        return $invitee;
    }

    /**
     * @param WixUser $user
     * @param string  $instanceId
     * @return WixUser
     * @throws \Doctrine\ORM\ORMException
     */
    public function createWixUser(WixUser $user, $instanceId)
    {
        $user->setPassword($this->encoder->encodePassword($user, $instanceId));
        $user->setRoles(['ROLE_USER']);
        $user->setActive(true);
        $user->setBranch($this->em->getReference('AppBundle:Branch', $user->getBranch()->getId()));
        $this->em->persist($user);
        $this->em->flush($user);

        return $user;
    }

    /**
     * @param string $username
     * @return bool
     */
    public function getWixUsernameUnique($username)
    {
        return $this->em->getRepository('AppBundle:Wix\WixUser')->getUsernameUnique($username);
    }

    /**
     * @param User $user
     * @return User
     */
    public function createReseller(User $user)
    {
        $user->setPassword($this->encoder->encodePassword($user, $user->getPlainPassword()));
        $user->setRoles($this->getNewResellerRoles());
        $user->setActive(true);
        $user->setCreated(new \DateTime);
        $user->setWelcomeSent(null);
        $user->setSlug($this->getUserSlug($user));
        $user->setApiKey($this->generateUserApiKey());
        $user->setIsRepReviewsClient(false);

        $company = $this->companyService->createCompany($user->getBranch()->getCompany());
        $user->getBranch()->setCompany($company);

        $branch = $this->branchService->createBranch($user->getBranch());
        $user->setBranch($branch);

        $user->setReseller(
            $this->em->getRepository(Reseller::class)->findOneBy(['reseller_key' => $user->getResellerKey()])
        );

        $user->setPlan(
            $this->em->getRepository(Plan::class)->findOneBy(['stripe_plan_id' => 'Wholesale'])
        );

        $this->em->persist($user);
        $this->em->flush();

        return $user;
    }

    /**
     * @return string
     */
    public function getSecurityHash()
    {
        return bin2hex(random_bytes(50));
    }

    /**
     * @param User $user
     * @return User
     */
    public function save(User $user)
    {
        $user->setPassword($this->encoder->encodePassword($user, $user->getPassword()));
        $this->em->persist($user);
        $this->em->flush();

        return $user;
    }

    /**
     * @param User $user
     * @return string
     */
    public function getUserSlug(User $user)
    {
        $slug = SlugUtilities::slugify($user->getFirstName() . ' ' . $user->getLastName());
        $slugIsUnique = false;
        $i = 1;
        $repo = $this->em->getRepository(User::class);

        while (!$slugIsUnique) {
            $query = $repo->isSlugUnique($slug);

            if (!$query) {
                $slug .= $i;
                $i++;
            } else {
                $slugIsUnique = true;
            }
        }

        return $slug;
    }

    /**
     * @param User $user
     * @return array|null
     */
    public function getUserEndorsementFeed(
        User $user,
        \DateTime $since = null,
        int $minimumReviewValue = null,
        bool $includeAuthorEmail = false,
        bool $includeVideosOnly = false
    ) {
        $surveys = $this->surveyService->getSurveysByUser($user, null);

        if (!$surveys) {
            return [];
        }

        return $this->endorsementResponseService->getEndorsementFeed(
            $surveys,
            $this->getMinimumReviewValue($user, $minimumReviewValue),
            $user,
            $this->getReviewAggregationTokens($user),
            $since,
            $includeAuthorEmail,
            $includeVideosOnly
        );
    }

    /**
     * @return string
     */
    public function generateUserApiKey()
    {
        return md5(uniqid());
    }

    /**
     * @param User $user
     * @return array
     */
    private function getNewUserRoles(User $user)
    {
        $roles = ['ROLE_USER'];

        // Add ROLE_BRANCH_ADMIN if no Branch Admin already exists
        if ($user->getBranch() && null !== $user->getBranch()->getId()) {
            $repo = $this->em->getRepository('AppBundle:User');
            $administrator = $repo->getBranchAdministrator($user->getBranch());

            if (null === $administrator) {
                $roles[] = 'ROLE_BRANCH_ADMIN';
            }
        } else {
            $roles[] = 'ROLE_BRANCH_ADMIN';
        }

        // Add ROLE_COMPANY_ADMIN if no Company Admin already exists
        if ($user->getBranch() &&
            $user->getBranch()->getCompany() &&
            null != $user->getBranch()->getCompany()->getId()
        ) {
            $repo = $this->em->getRepository('AppBundle:User');
            $administrators = $repo->getCompanyAdministrator($user->getBranch()->getCompany());

            if (null === $administrators) {
                $roles[] = 'ROLE_COMPANY_ADMIN';
            }
        } else {
            $roles[] = 'ROLE_COMPANY_ADMIN';
        }

        return $roles;
    }

    /**
     * @return array
     */
    private function getNewResellerRoles()
    {
        return ['ROLE_COMPANY_ADMIN', 'ROLE_BRANCH_ADMIN', 'ROLE_USER', 'ROLE_RESELLER'];
    }

    /**
     * @param User $user
     * @return array
     */
    public function getUserIdsByUserRole(User $user)
    {
        $userRepo = $this->em->getRepository('AppBundle:User');
        $isCompanyAdmin = $this->authChecker->isGranted('ROLE_COMPANY_ADMIN', $user);
        $isBranchAdmin = $this->authChecker->isGranted('ROLE_BRANCH_ADMIN', $user);

        $users[] = $user->getId();

        // Retrieve for company
        if ($isCompanyAdmin) {
            $companyUsers = $userRepo->getUsersByCompany($user->getBranch()->getCompany());
            /** @var User $user */
            foreach ($companyUsers as $user) {
                $users[] = $user->getId();
            }
        }

        // Retrieve for branch
        if (!$isCompanyAdmin && $isBranchAdmin) {
            $branchUsers = $userRepo->getUsersByBranch($user->getBranch());
            /** @var User $user */
            foreach ($branchUsers as $user) {
                $users[] = $user->getId();
            }
        }

        return array_unique($users);
    }

    /**
     * @param User $user
     * @param User $branchAdmin
     * @return bool
     */
    public function getIsUsersBranchAdmin(User $user, User $branchAdmin)
    {
        return $user->getBranch()->getId() === $branchAdmin->getBranch()->getId();
    }

    /**
     * @param User $user
     * @param User $companyAdmin
     * @return bool
     */
    public function getIsUsersCompanyAdmin(User $user, User $companyAdmin)
    {
        return $user->getBranch()->getCompany()->getId() === $companyAdmin->getBranch()->getCompany()->getId();
    }

    /**
     * @param User $user
     * @return string
     */
    public function getPasswordResetLink(User $user)
    {
        return $this->container->getParameter('ng') .
            $this->container->getParameter('front_end_password_reset_uri') .
            '?h=' . $user->getSecurityHash() .
            '&u='.md5($user->getUsername()).
            '&i='.$user->getUsername();
    }

    /**
     * @param User $inviter
     * @return \AppBundle\Entity\Stripe\Plan|null|object
     */
    public function getInviteePlan(Company $company, Branch $branch)
    {
        /** @var PlanRepository $planRepo */
        $planRepo = $this->em->getRepository(Plan::class);

        /** @var UserRepository $userRepo */
        $userRepo = $this->em->getRepository(User::class);

        switch ($company->getPayeeLevel()) {
            case PayeeLevel::USER:
                return $planRepo->findOneBy(['acl' => FeatureAccessLevel::FREE]);
            case PayeeLevel::BRANCH:
                /** @var User $branchAdmin */
                $branchAdmin = $userRepo->getBranchAdministrator($branch);
                return $branchAdmin->getPlan();
            case PayeeLevel::COMPANY:
                /** @var User $companyAdmin */
                $companyAdmin = $userRepo->getCompanyAdministrator($company);
                return $companyAdmin->getPlan();
            default:
                return $planRepo->findOneBy(['acl' => FeatureAccessLevel::FREE]);
        }
    }

    /**
     * @param User $invitee
     */
    public function updateInviteeSubscription(User $invitee)
    {
        // Only non-reseller or unbundled reseller accounts affect Stripe
        if (null === $invitee->getReseller() ||
            $invitee->getReseller() && !$invitee->getReseller()->getBundled()
        ) {
            $userRepo = $this->em->getRepository(User::class);
            $company = $invitee->getBranch()->getCompany();

            if ($company->getPayeeLevel() === PayeeLevel::COMPANY) {
                /** @var User $companyAdmin */
                $companyAdmin = $userRepo->getCompanyAdministrator($company);

                // Update the invitee's plan
                $invitee->setPlan($companyAdmin->getPlan());
                $this->em->persist($invitee);
                $this->em->flush();

                // Update the company subscription quantity
                $this->planService->incrementCompanySubscriptionQuantity($company, $companyAdmin);
            }

            if ($company->getPayeeLevel() === PayeeLevel::BRANCH) {
                /** @var User $branchAdmin */
                $branchAdmin = $userRepo->getBranchAdministrator($invitee->getBranch());

                // Update the invitee's plan
                $invitee->setPlan($branchAdmin->getPlan());
                $this->em->persist($invitee);
                $this->em->persist($invitee);
                $this->em->flush();

                $this->planService->incrementBranchSubscriptionQuantity($invitee->getBranch(), $branchAdmin);
            }
        }
    }

    /**
     * @param User $user
     */
    private function updateUserSubscription(User $user)
    {
        switch ($user->getBranch()->getCompany()->getPayeeLevel()) {
            case (PayeeLevel::BRANCH):
                $payee = $this->em->getRepository('AppBundle:User')->getBranchAdministrator($user->getBranch());
                if (null !== $payee) {
                    $this->planService->updateBranchSubscriptionQuantity($user->getBranch(), $payee);
                }
                return;
            case (PayeeLevel::COMPANY):
                $payee = $this->em->getRepository('AppBundle:User')
                    ->getCompanyAdministrator($user->getBranch()->getCompany());
                if (null !== $payee) {
                    $this->planService->updateCompanySubscriptionQuantity($user->getBranch()->getCompany(), $payee);
                }
                return;
            case (PayeeLevel::USER):
                $this->stripeService->cancelUserSubscription($user);
                break;
            default:
                return;
        }
    }

    /**
     * @param User $user
     * @param User $u
     * @return User
     *
     * Everyone starts with a free plan, except for bundled reseller accounts - they're automatically
     * entered into an premium plan with a 100% discount
     */
    private function setResellerAndPlan(User $user, User $u)
    {
        /** @var PlanRepository $planRepo */
        $planRepo = $this->em->getRepository(Plan::class);

        /** @var Plan $freePlan */
        $freePlan = $planRepo->findOneBy(['acl' => FeatureAccessLevel::FREE]);

        /** @var Plan $premiumPlan */
        $premiumPlan = $planRepo->findOneBy(['acl' => FeatureAccessLevel::PREMIUM_PLUS_MONTHLY]);

        // Everyone starts on the Free Plan
        $u->setPlan($freePlan);

        // Bundled Reseller account? Board to premium plan?
        if ($user->getResellerKey()) {
            /** @var ResellerRepository $resellerRepo */
            $resellerRepo = $this->em->getRepository(Reseller::class);

            /** @var Reseller $reseller */
            $reseller = $resellerRepo->findOneBy(['reseller_key' => $user->getResellerKey()]);

            if ($reseller) {
                $u->setReseller($reseller);

                if ($reseller->getBundled()) {
                    $u->setPlan($premiumPlan);
                }
            }
        }

        return $u;
    }

    /**
     * @param User $user
     * @return array
     */
    private function getReviewAggregationTokens(User $user)
    {
        $arr = [];

        // If the user has no preferences, default to include review aggregation tokens.  Otherwise, use setting.
        if (!$user->getPreferences() ||
            ($user->getPreferences() && $user->getPreferences()->getIncludeExternalReviewsInFeeds())
        ) {
            if (null !== $user->getGoogleReviewAggregationToken()) {
                $arr[] = $user->getGoogleReviewAggregationToken();
            }

            if (null !== $user->getFacebookReviewAggregationToken()) {
                $arr[] = $user->getFacebookReviewAggregationToken();
            }

            if (null !== $user->getZillowNmlsidToken()) {
                $arr[] = $user->getZillowNmlsidToken();
            }

            if (null !== $user->getZillowScreenNameToken()) {
                $arr[] = $user->getZillowScreenNameToken();
            }
        }

        return $arr;
    }

    /**
     * @param User $user
     * @param int|null $minimumScore
     * @return float|int
     */
    private function getMinimumReviewValue(User $user, int $minimumScore = null)
    {
        if (null !== $minimumScore) {
            return $minimumScore;
        }

        $company = $user->getBranch()->getCompany();

        $feed = ($this->feedService->isFeedOverridden($company)) ?
            $this->em->getRepository(FeedSetting::class)->findOneBy(['company' => $company->getId()]) :
            $this->em->getRepository(FeedSetting::class)->findOneBy(['user' => $user->getId()]);

        if ($feed) {
            return $feed->getMinimumReviewValue();
        }

        return self::DEFAULT_MINIMUM_REVIEW_VALUE;
    }
}
