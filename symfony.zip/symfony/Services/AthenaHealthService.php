<?php

namespace AppBundle\Services;

use AppBundle\Entity\AthenaPractice;
use AppBundle\Entity\AthenaProvider;
use AppBundle\Entity\User;
use Doctrine\ORM\EntityManager;
use GuzzleHttp\Client as Guzzler;
use GuzzleHttp\Exception\RequestException;
use Symfony\Component\HttpFoundation\Response;

class AthenaHealthService
{
    const APPOINTMENT_STATUS_OPEN                   = 1;
    const APPOINTMENT_STATUS_FILLED                 = "f";
    const APPOINTMENT_STATUS_CANCELLED              = "x";
    const APPOINTMENT_STATUS_CHECKED_IN             = 2;
    const APPOINTMENT_STATUS_CHECKED_OUT            = 3;
    const APPOINTMENT_STATUS_CHARGE_ENTERED         = 4;

    /** @var EntityManager $em */
    private $em;

    /** @var string $athenaHealthEndpoint */
    private $athenaHealthEndpoint;

    /** @var string $athenaHealthAuthEndpoint */
    private $athenaHealthAuthEndpoint;

    /** @var string $athenaHealthKey */
    private $athenaHealthKey;

    /** @var string $athenaHealthSecret */
    private $athenaHealthSecret;

    public function __construct(
        EntityManager $em,
        string $athenaHealthEndpoint,
        string $athenaHealthAuthEndpoint,
        string $athenaHealthKey,
        string $athenaHealthSecret
    ) {
        $this->em = $em;
        $this->athenaHealthEndpoint = $athenaHealthEndpoint;
        $this->athenaHealthAuthEndpoint = $athenaHealthAuthEndpoint;
        $this->athenaHealthKey = $athenaHealthKey;
        $this->athenaHealthSecret = $athenaHealthSecret;
    }

    /**
     * @param AthenaPractice $practice
     * @return AthenaPractice|bool
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function addPractice(AthenaPractice $practice)
    {
        $canAccessPractice = $this->canAccessPractice($practice->getAthenaPracticeId());

        if (!$canAccessPractice) {
            return false;
        }

        $this->em->persist($practice);
        $this->em->flush();

        return $practice;
    }

    /**
     * @param AthenaPractice $practice
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     */
    public function deletePractice(AthenaPractice $practice)
    {
        // Remove all associated providers
        $this->truncateProviders($practice);

        $this->em->remove($practice);
        $this->em->flush();
    }

    /**
     * @param AthenaPractice $practice
     * @param array $providers
     * @return \stdClass
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function addProvidersToPractice(AthenaPractice $practice, array $providers)
    {
        // Remove all providers from practice
        $this->truncateProviders($practice);

        $results = new \stdClass;
        $results->added = [];
        $results->notAdded = [];

        $accessibleProviders = $this->getProviders($practice->getAthenaPracticeId());

        /** @var AthenaProvider $provider */
        foreach ($providers as $provider) {
            if ($this->canAccessProvider($provider, $accessibleProviders)) {
                $this->em->persist($provider);
                $results->added[] = $provider->getUser()->getFirstName() . ' ' . $provider->getUser()->getLastName();
            } else {
                $results->notAdded[] = $provider->getUser()->getFirstName() . ' ' . $provider->getUser()->getLastName();
            }
        }

        if (count($results->added)) {
            $this->em->flush();
        }

        return $results;
    }

    /**
     * @param AthenaPractice $practice
     * @param AthenaProvider $provider
     * @return AthenaProvider
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     */
    public function addProvider(AthenaPractice $practice, AthenaProvider $provider)
    {
        $provider->setAthenaPractice($practice);

        $this->em->persist($provider);
        $this->em->flush();

        return $provider;
    }

    /**
     * @param array $datum
     * @return AthenaProvider
     */
    public function createProviderFromArray(AthenaPractice $practice, array $datum)
    {
        $provider = new AthenaProvider;
        $provider->setAthenaPractice($practice);
        $provider->setUser($this->em->getReference(User::class, $datum["user"]));
        $provider->setAthenaProviderId($datum["athena_provider"]);

        return $provider;
    }

    /**
     * @param string $practiceId
     * @return bool|mixed
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function getProviders(string $practiceId)
    {
        $token = $this->authenticate();

        if (!$token) {
            return false;
        }

        $client = new Guzzler;

        try {
            $response = $client->request(
                'GET',
                $this->athenaHealthEndpoint . '/' . $practiceId . '/providers',
                [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $token->access_token,
                    ],
                ]
            );

            return json_decode($response->getBody()->getContents(), true);
        } catch (RequestException $e) {
            return false;
        }
    }

    /**
     * @param AthenaPractice $practice
     * @throws \Doctrine\ORM\ORMException
     * @throws \Doctrine\ORM\OptimisticLockException
     */
    private function truncateProviders(AthenaPractice $practice)
    {
        $providers = $this->em->getRepository(AthenaProvider::class)
            ->findBy(['athenaPractice' => $practice->getId()]);

        if (count($providers)) {
            foreach ($providers as $provider) {
                $this->em->remove($provider);
            }

            $this->em->flush();
        }
    }

    /**
     * @param string $athenaPracticeId
     * @return bool
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    private function canAccessPractice(string $athenaPracticeId)
    {
        $token = $this->authenticate();

        if (!$token) {
            return false;
        }

        $client = new Guzzler;

        try {
            $response = $client->request(
                'GET',
                $this->athenaHealthEndpoint . '/' . $athenaPracticeId . '/ping',
                [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $token->access_token,
                    ],
                ]
            );

            return Response::HTTP_OK === $response->getStatusCode() ? true: false;
        } catch (RequestException $e) {
            return false;
        }
    }

    /**
     * @param AthenaProvider $provider
     * @param array $accessibleProviders
     * @return bool
     */
    private function canAccessProvider(AthenaProvider $provider, array $accessibleProviders)
    {
        foreach ($accessibleProviders as $accessibleProvider) {
            foreach ($accessibleProvider as $p) {
                if ($p["providerid"] == $provider->getAthenaProviderId()) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * @param string $practiceId
     * @param \DateTime $startDate
     * @param \DateTime $endDate
     * @param $providerId
     * @param null $appointmentStatus
     * @return bool|mixed
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function getAppointments(
        string $practiceId,
        \DateTime $startDate,
        \DateTime $endDate,
        string $providerId,
        $appointmentStatus = null
    ) {
        $token = $this->authenticate();

        $client = new Guzzler;

        try {
            $response = $client->request(
                'GET',
                $this->athenaHealthEndpoint . '/' . $practiceId . '/appointments/booked',
                [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $token->access_token,
                    ],
                    'query' => [
                        'startdate' => $startDate->format('m/d/Y'),
                        'enddate' => $endDate->format('m/d/Y'),
                        'showexpectedprocedurecodes' => false,
                        'providerid' => $providerId,
                        'appointmentstatus' => $appointmentStatus,
                    ],
                ]
            );

            return json_decode($response->getBody()->getContents(), true);
        } catch (RequestException $e) {
            return false;
        }
    }

    /**
     * @param string $practiceId
     * @param string $patientId
     * @return bool|mixed
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function getPatient(string $practiceId, string $patientId)
    {
        $token = $this->authenticate();

        $client = new Guzzler;

        try {
            $response = $client->request(
                'GET',
                $this->athenaHealthEndpoint . '/' . $practiceId . '/patients/' . $patientId,
                [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $token->access_token
                    ],
                    'query' => [
                        'show2015edcehrtvalues' => false,
                        'showallclaims' => false,
                        'showallpatientdepartmentstatus' => false,
                        'showbalancedetails' => false,
                        'showcustomfields' => false,
                        'showfullssn' => false,
                        'showinsurance' => false,
                        'showlocalpatientid' => false,
                        'showportalstatus' => false
                    ]
                ]
            );

            return json_decode($response->getBody()->getContents(), true);
        } catch (RequestException $e) {
            return false;
        }
    }

    /**
     * @return bool|mixed
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    private function authenticate()
    {
        // Get a new token
        $client = new Guzzler;

        try {
            $response = $client->request(
                'POST',
                $this->athenaHealthAuthEndpoint,
                [
                    'headers' => [
                        'Content-type' => 'application/x-www-form-urlencoded',
                    ],
                    'auth' => [
                        $this->athenaHealthKey,
                        $this->athenaHealthSecret,
                    ],
                    'form_params' => ['grant_type' => 'client_credentials'],
                ]
            );

            return json_decode($response->getBody()->getContents());
        } catch (RequestException $e) {
            return false;
        }
    }
}
