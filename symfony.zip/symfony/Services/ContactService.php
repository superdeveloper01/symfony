<?php

namespace AppBundle\Services;

use AppBundle\Entity\Contact;
use AppBundle\Entity\PracticePantherToken;
use AppBundle\Entity\Survey;
use AppBundle\Entity\User;
use AppBundle\Model\MappedContactList;
use AppBundle\Repository\ContactRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\EntityManager;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class ContactService
{
    /** @var EntityManager */
    private $em;

    /** @var ValidatorInterface */
    private $validator;

    /** @var ContactRepository */
    private $repo;

    /** @var EndorsementRequestService */
    private $endorsementRequestService;

    private $practicePantherService;

    /**
     * ContactService constructor.
     * @param ContactRepository $repo
     */
    public function __construct(
        EntityManager $em,
        ValidatorInterface $validator,
        ContactRepository $repo,
        EndorsementRequestService $endorsementRequestService,
        PracticePantherService $practicePantherService
    ) {
        $this->repo = $repo;
        $this->em = $em;
        $this->validator = $validator;
        $this->endorsementRequestService = $endorsementRequestService;
        $this->practicePantherService = $practicePantherService;
    }

    /**
     * @param Contact $contact
     * @param User $user
     * @return Contact
     */
    public function create(Contact $contact, User $user)
    {
        $contact->setUser($user);
        $contact->setDoNotText(true === $contact->getDoNotText() ? true : false);
        $contact->setActive(true);

        // If the contact already exists, update the existing contact
        $contactExists = $this->em->getRepository(Contact::class)->findOneBy([
            'email' => $contact->getEmail(),
            'user' => $user->getId()
        ]);

        if ($contactExists) {
            return $this->update($contactExists, $contact);
        }

        return $this->repo->save($contact);
    }

    /**
     * @param Contact $contact
     * @param Contact $c
     * @return Contact
     */
    public function update(Contact $contact, Contact $c)
    {
        $contact->setFirstName($c->getFirstName());
        $contact->setLastName($c->getLastName());
        $contact->setEmail($c->getEmail());
        $contact->setCity($c->getCity());
        $contact->setState($c->getState());
        $contact->setPhone($c->getPhone());
        $contact->setSecondaryPhone($c->getSecondaryPhone());
        $contact->setDoNotText(true === $c->getDoNotText() ? true : false);
        $contact->setFacebookImAddress($c->getFacebookImAddress());
        $contact->setActive($c->getActive());
        $this->repo->save($contact);

        return $contact;
    }

    /**
     * @param array $contact
     * @param User $user
     * @return Contact
     */
    public function createContactFromArray(array $contact, User $user)
    {
        $c = new Contact();

        if (array_key_exists('first_name', $contact)) {
            $c->setFirstName($contact['first_name']);
        }

        if (array_key_exists('last_name', $contact)) {
            $c->setLastName($contact['last_name']);
        }

        if (array_key_exists('email', $contact)) {
            $c->setEmail($contact['email']);
        }

        if (array_key_exists('city', $contact)) {
            $c->setCity($contact['city']);
        }

        if (array_key_exists('state', $contact)) {
            $c->setState($contact['state']);
        }

        if (array_key_exists('phone', $contact)) {
            $c->setPhone($contact['phone']);
        }

        if (array_key_exists('secondary_phone', $contact)) {
            $c->setSecondaryPhone($contact['secondary_phone']);
        }

        if (array_key_exists('facebook_im_address', $contact)) {
            $c->setFacebookImAddress($contact['facebook_im_address']);
        }

        $c->setDoNotText(
            array_key_exists('do_not_text', $contact) && "true" == $contact['do_not_text'] ? true : false
        );


        $c->setActive(true);
        $c->setUser($user);

        return $c;
    }

    /**
     * @param Contact $contact
     */
    public function delete(Contact $contact)
    {
        $contact->setActive(false);
        $this->repo->save($contact);
    }

    /**
     * @param Contact $contact
     * @return Contact
     */
    public function save(Contact $contact)
    {
        $contact->setActive(true);
        return $this->repo->save($contact);
    }

    /**
     * $candidates[0] = username
     * $candidates[1] = contact first name
     * $candidates[2] = contact last name
     * $candidates[3] = contact e-mail
     * $candidates[4] = contact phone
     * $candidates[5] = contact mobile
     * @param array $candidates
     * @param bool $sendEndorsementRequests
     * @return \stdClass
     */
    public function assignAndImportContacts(array $candidates, $sendEndorsementRequests = false)
    {
        $contacts = [];
        $errors = [];
        $userRepo = $this->em->getRepository(User::class);

        foreach ($candidates as $candidate) {
            $user = $userRepo->findOneBy(['username' => $candidate[0]]);

            if ($user && $user->getActive()) {
                $contact = new Contact;
                $contact->setFirstName($candidate[1]);
                $contact->setLastName($candidate[2]);
                $contact->setEmail($candidate[3]);
                $contact->setCity(null);
                $contact->setState(null);
                $contact->setPhone((empty($candidate[4])) ? null: $candidate[4]);
                $contact->setSecondaryPhone(empty($candidate[5]) ? null : $candidate[5]);
                $contact->setFacebookImAddress(null);
                $contact->setDoNotText(false);

                $e = $this->validator->validate($contact, null, ["contact_post"]);

                if (count($e) > 0) {
                    $errors[] = $contact->getEmail() . ': ' . (string) $e;
                } else {
                    $c = $this->create($contact, $user);

                    $contacts[] = $c;

                    if ($sendEndorsementRequests) {
                        $surveys = $user->getSurveys();

                        /** @var $surveys ArrayCollection */
                        if (count($surveys) && $surveys[0]->getActive()) {
                            $this->createEndorsementRequestForContact($contact, $surveys[0]);
                        }
                    }
                }
            }
        }

        $response = new \stdClass;
        $response->contacts = $contacts;
        $response->errors = $errors;

        return $response;
    }

    /**
     * @param MappedContactList $contactList
     * @param User $user
     * @return array
     */
    public function importMappedContactList(MappedContactList $contactList, User $user)
    {
        $response = new \stdClass;
        $response->contacts_created = [];
        $response->errors = [];

        /** @var UploadedFile $file */
        $file = $contactList->getFile();
        $filename = md5(uniqid()) . '.' . $file->guessExtension();
        $filedir = 'contact-uploads';

        $file->move($filedir, $filename);

        // Replace Windows newline chars
        $file_contents = file_get_contents($filedir . '/' . $filename);
        $file_contents_new = str_replace("\r", "\n", $file_contents);
        $file_contents_new = str_replace("\n\n", "\n", $file_contents_new);
        file_put_contents($filedir . '/' . $filename, $file_contents_new);

        $csv = fopen($filedir . '/' . $filename, "r");

        $headers = fgetcsv($csv);

        $map = $this->getMapObject($contactList);

        $positions = $this->parseCsvHeader($headers, $map);

        // If there's no header row, reopen the CSV file so we can iterate over all rows, including the first one
        if (!$contactList->getFileIncludesHeaderRow()) {
            $csv = fopen($filedir . '/' . $filename, "r");
        }

        while ($row = fgetcsv($csv)) {
            $contact = $this->createContactFromCsvRecord($positions, $row, $user);

            $errors = $this->validator->validate($contact, null, ["contact_post"]);

            if (count($errors) > 0) {
                $response->errors[$contact->getEmail()] = [];

                foreach ($errors as $error) {
                    array_push($response->errors[$contact->getEmail()], (string) $error->getMessage());
                }
            } else {
                $contact = $this->save($contact);

                array_push($response->contacts_created, $contact);

                if ($contactList->getSendSurvey()) {
                    /** @var Survey $defaultSurvey */
                    $defaultSurvey = $this->em->getRepository(Survey::class)->getDefaultSurvey($contact->getUser());

                    if ($defaultSurvey && $defaultSurvey->getActive()) {
                        $this->createEndorsementRequestForContact($contact, $defaultSurvey);
                    }
                }
            }
        }

        return (array) $response;
    }

    /**
     * @param array $ppContact
     * @param User $user
     * @return Contact|bool|null|object
     */
    public function createContactFromPracticePantherContact(array $ppContact, User $user)
    {
        if (array_key_exists('email', $ppContact)) {
            $existingContact = $this->em->getRepository(Contact::class)->findOneBy([
                'email' => $ppContact['email'],
                'user' => $user->getId()
            ]);

            $contact = $existingContact ? $existingContact : new Contact;

            $contact->setEmail($ppContact['email']);
            $contact->setActive(true);
            $contact->setUser($user);
            $contact->setDoNotText(false);

            if (array_key_exists('first_name', $ppContact) && !empty($ppContact['first_name'])) {
                $contact->setFirstName($ppContact['first_name']);
            }

            if (array_key_exists('last_name', $ppContact) && !empty($ppContact['last_name'])) {
                $contact->setLastName($ppContact['last_name']);
            }

            if (array_key_exists('phone_work', $ppContact) && !empty($ppContact['phone_work'])) {
                $contact->setPhone($ppContact['phone_work']);
            }

            if (array_key_exists('phone_mobile', $ppContact)) {
                $contact->setSecondaryPhone($ppContact['phone_mobile']);
            }

            $this->repo->save($contact);

            return $contact;
        }

        return false;
    }

    /**
     * @param array $athenaPatient
     * @param User $user
     * @return Contact|bool|object|null
     */
    public function createContactFromAthenaPatient(array $athenaPatient, User $user)
    {
        if ($this->canImportAthenaPatient($athenaPatient)) {
            $existingContact = $this->em->getRepository(Contact::class)->findOneBy([
                'email' => trim($athenaPatient['email']),
                'user' => $user->getId()
            ]);

            $contact = $existingContact ? $existingContact : new Contact;

            $contact->setEmail(trim($athenaPatient['email']));
            $contact->setActive(true);
            $contact->setUser($user);

            if (array_key_exists('firstname', $athenaPatient) && !empty($athenaPatient['firstname'])) {
                $contact->setFirstName(trim($athenaPatient['firstname']));
            }

            if (array_key_exists('lastname', $athenaPatient) && !empty($athenaPatient['lastname'])) {
                $contact->setLastName(trim($athenaPatient['lastname']));
            }

            if (array_key_exists('mobilephone', $athenaPatient) && !empty($athenaPatient['mobilephone'])) {
                $contact->setSecondaryPhone(trim($athenaPatient['mobilephone']));
            }

            if (array_key_exists('consenttotext', $athenaPatient)) {
                $contact->setDoNotText(true === $athenaPatient['consenttotext'] ? false : true);
            } else {
                $contact->setDoNotText(true);
            }

            // Validate the contact before persisting
            $errors = $this->validator->validate($contact, null, ["contact_post"]);

            if (!count($errors)) {
                $this->repo->save($contact);

                return $contact;
            }
        }

        return false;
    }

   /**
     * @param array $client
     * @param User $user
     * @return Contact|bool|object|null
     */
    public function createContactFromClioAccount(array $client, User $user)
    {
        if (array_key_exists('primary_email_address', $client)) {
            $existingContact = $this->em->getRepository(Contact::class)->findOneBy([
                'email' => trim($client['primary_email_address']),
                'user' => $user->getId()
            ]);

            $contact = $existingContact ? $existingContact : new Contact;

            $contact->setEmail(trim($client['primary_email_address']));
            $contact->setActive(true);
            $contact->setUser($user);
            $contact->setDoNotText(false);

            if($client['type'] == 'Company') {
                if (array_key_exists('name', $client) && !empty($client['name'])) {
                    $name = explode(" ", $client['name']);
                }
            } else {
                if (array_key_exists('first_name', $client) && !empty($client['first_name'])) {
                    $contact->setFirstName(trim($client['first_name']));
                }
                if (array_key_exists('last_name', $client) && !empty($client['last_name'])) {
                    $contact->setLastName(trim($client['last_name']));
                }
            }

            if (array_key_exists('primary_phone_number', $client) && !empty($client['primary_phone_number'])) {
                $contact->setPhone(trim($client['primary_phone_number']));
            }

            // Validate the contact before persisting
            $errors = $this->validator->validate($contact, null, ["contact_post"]);

            if (!count($errors)) {
                $this->repo->save($contact);
                return $contact;
            }
        }
    }

    /**
     * @param array $athenaPatient
     * @return bool
     */
    private function canImportAthenaPatient(array $athenaPatient)
    {
        // Must have an e-mail address to import
        if (!array_key_exists('emailexists', $athenaPatient) || empty($athenaPatient['email'])) {
            return false;
        }

        // Must have a DOB to import
        if (!array_key_exists('dob', $athenaPatient) || empty($athenaPatient['dob'])) {
            return false;
        }

        // Must be able to convert DOB to a Unix timestamp
        try {
            $patientsAge = strtotime(stripslashes($athenaPatient['dob']));
        } catch (\Exception $e) {
            return false;
        }

        // If we successfully convert DOB to a Unix timestamp, the patient must be 18 or older
        if (isset($patientsAge)) {
            $minimumAge = strtotime('-18 years');

            return $minimumAge > $patientsAge;
        }

        // Otherwise, return false as a safety fallback
        return false;
    }

    /**
     * @param Contact $contact
     * @param Survey $survey
     * @return \AppBundle\Document\EndorsementRequest
     */
    private function createEndorsementRequestForContact(Contact $contact, Survey $survey)
    {
        $arr = [
            'survey_id' => $survey->getId(),
            'recipient_email' => $contact->getEmail()
        ];

        if (null !== $contact->getFirstName()) {
            $arr['recipient_first_name'] = $contact->getFirstName();
        }

        if (null !== $contact->getLastName()) {
            $arr['recipient_last_name'] = $contact->getLastName();
        }

        if (null !== $contact->getCity()) {
            $arr['recipient_city'] = $contact->getCity();
        }

        if (null !== $contact->getState()) {
            $arr['recipient_state'] = $contact->getState();
        }

        $endorsementRequest = $this->endorsementRequestService->createEndorsementRequestFromArray($arr);
        $saved = $this->endorsementRequestService->save($endorsementRequest);

        return $saved;
    }

    /**
     * @param MappedContactList $contactList
     * @return \stdClass
     */
    private function getMapObject(MappedContactList $contactList)
    {
        /** @var \stdClass $legend */
        $legend = new \stdClass();

        // Pre-seed the returned legend with bool values
        $legend->user = false;
        $legend->firstName = false;
        $legend->lastName = false;
        $legend->email = false;
        $legend->city = false;
        $legend->state = false;
        $legend->phone = false;
        $legend->secondaryPhone = false;
        $legend->facebookImAddress = false;

        /** @var array $map */
        $map = $contactList->getMap();

        foreach ($map as $key => $value) {
            if ('user' === $key) {
                $legend->user = $value;
            }

            if ('first_name' === $key) {
                $legend->firstName = $value;
            }

            if ('last_name' === $key) {
                $legend->lastName = $value;
            }

            if ('email' === $key) {
                $legend->email = $value;
            }

            if ('city' === $key) {
                $legend->city = $value;
            }

            if ('state' === $key) {
                $legend->state = $value;
            }

            if ('phone' === $key) {
                $legend->phone = $value;
            }

            if ('secondary_phone' === $key) {
                $legend->secondaryPhone = $value;
            }

            if ('facebook_im_address' === $key) {
                $legend->facebookImAddress = $value;
            }
        }

        return $legend;
    }

    /**
     * @param array $headers
     * @param \stdClass $map
     * @return \stdClass
     */
    private function parseCsvHeader(array $headers, \stdClass $map)
    {
        $positions = new \stdClass;

        // Pre-seed positions
        $positions->user = false;
        $positions->firstName = false;
        $positions->lastName = false;
        $positions->email = false;
        $positions->city = false;
        $positions->state = false;
        $positions->phone = false;
        $positions->secondaryPhone = false;
        $positions->facebookImAddress = false;

        foreach ($headers as $key => $header) {
            if ($map->user === $header) {
                $positions->user = $key;
            }

            if ($map->firstName === $header) {
                $positions->firstName = $key;
            }

            if ($map->lastName === $header) {
                $positions->lastName = $key;
            }

            if ($map->email === $header) {
                $positions->email = $key;
            }

            if ($map->city === $header) {
                $positions->city = $key;
            }

            if ($map->state === $header) {
                $positions->state = $key;
            }

            if ($map->phone === $header) {
                $positions->phone = $key;
            }

            if ($map->secondaryPhone === $header) {
                $positions->secondaryPhone = $key;
            }

            if ($map->facebookImAddress === $header) {
                $positions->facebookImAddress = $key;
            }
        }

        return $positions;
    }

    /**
     * @param \stdClass $positions
     * @param array $row
     * @param User $user
     * @return Contact|null|object
     */
    private function createContactFromCsvRecord(\stdClass $positions, array $row, User $user)
    {
        $userRepo = $this->em->getRepository(User::class);
        $contactRepo = $this->em->getRepository(Contact::class);

        // Set a contact for the user
        $contactUser = (false !== $positions->user) ?
            $userRepo->findOneBy(['username' => $row[$positions->user]]) :
            $user;

        if (!$contactUser) {
            $contactUser = $user;
        }

        $existingContact = $contactRepo->findOneBy(['user' => $contactUser, 'email' => $row[$positions->email]]);

        $contact = ($existingContact) ? $existingContact : new Contact;
        $contact->setUser($contactUser);
        $contact->setEmail($row[$positions->email]);
        $contact->setDoNotText(false);
        $contact->setActive(true);

        if (false !== $positions->firstName) {
            $contact->setFirstName(
                "" == $row[$positions->firstName] ? null : $row[$positions->firstName]
            );
        }

        if (false !== $positions->lastName) {
            $contact->setLastName(
                "" == $row[$positions->lastName] ? null : $row[$positions->lastName]
            );
        }

        if (false !== $positions->city) {
            $contact->setCity(
                "" == $row[$positions->city] ? null : $row[$positions->city]
            );
        }

        if (false !== $positions->state) {
            $contact->setState(
                "" == $row[$positions->state] ? null : $row[$positions->state]
            );
        }

        if (false !== $positions->phone) {
            $contact->setPhone(
                "" == $row[$positions->phone] ? null : $row[$positions->phone]
            );
        }

        if (false !== $positions->secondaryPhone) {
            $contact->setSecondaryPhone(
                "" == $row[$positions->secondaryPhone] ? null : $row[$positions->secondaryPhone]
            );
        }

        if (false !== $positions->facebookImAddress) {
            $contact->setFacebookImAddress(
                "" == $row[$positions->facebookImAddress] ? null : $row[$positions->facebookImAddress]
            );
        }

        return $contact;
    }
}
