<?php

namespace AppBundle\Services;

use AppBundle\Enumeration\EndorsementResponseStatus;
use Doctrine\ODM\MongoDB\DocumentManager;
use Doctrine\ORM\EntityManager;
use AppBundle\Document\EndorsementDispute;
use AppBundle\Enumeration\EndorsementDisputeStatus;

/**
 * Class EndorsementDisputeService
 * @package AppBundle\Services
 */
class EndorsementDisputeService
{
    /** @var EntityManager */
    private $em;

    /** @var DocumentManager */
    private $dm;

    /** @var string $frontEndUiUrl */
    private $frontEndUiUrl;

    /** @var string $frontEndAdminDisputeUri */
    private $frontEndAdminDisputeUri;

    /**
     * EndorsementDisputeService constructor.
     * @param EntityManager $em
     * @param DocumentManager $dm
     * @param $frontEndUiUrl
     * @param $frontEndSurveyUri
     */
    public function __construct(
        EntityManager $em,
        DocumentManager $dm,
        $frontEndUiUrl,
        $frontEndAdminDisputeUri
    ) {
        $this->em = $em;
        $this->dm = $dm;
        $this->frontEndUiUrl = $frontEndUiUrl;
        $this->frontEndAdminDisputeUri = $frontEndAdminDisputeUri;
    }

    /**
     * @param EndorsementDispute $endorsementDispute
     * @return EndorsementDispute
     */
    public function create(EndorsementDispute $endorsementDispute)
    {
        $dispute = new EndorsementDispute;
        $dispute->setStatus(EndorsementDisputeStatus::ACTIVE);
        $dispute->setDisputeReason($endorsementDispute->getDisputeReason());
        $dispute->setEndorsementResponse($endorsementDispute->getEndorsementResponse());
        $dispute->setSubmittedDate(new \DateTime());
        $dispute->setUpdatedDate(new \DateTime());
        $this->dm->persist($dispute);

        $endorsementResponse = $dispute->getEndorsementResponse();
        $endorsementResponse->setStatus(EndorsementResponseStatus::DISPUTE_PROGRESS);
        $endorsementResponse->setEndorsementDispute($dispute);
        $this->dm->persist($endorsementResponse);

        $this->dm->flush();

        return $dispute;
    }

    /**
     * @param EndorsementDispute $original
     * @param EndorsementDispute $update
     * @return EndorsementDispute
     */
    public function update(EndorsementDispute $original, EndorsementDispute $update)
    {
        $original->setDisputeReason($update->getDisputeReason());
        $original->setUpdatedDate(new \DateTime);
        $this->dm->persist($original);
        $this->dm->flush();

        return $original;
    }

    /**
     * @param EndorsementDispute $original
     * @param EndorsementDispute $update
     * @return EndorsementDispute
     */
    public function setStatus(EndorsementDispute $original, EndorsementDispute $update)
    {
        $original->setStatus($update->getStatus());
        $original->setUpdatedDate(new \DateTime());
        $this->dm->persist($original);

        $endorsementResponse = $original->getEndorsementResponse();

        switch ($original->getStatus()) {
            case EndorsementDisputeStatus::APPROVED:
                $endorsementResponse->setStatus(EndorsementResponseStatus::DISPUTE_APPROVED);
                break;
            case EndorsementDisputeStatus::REJECTED:
                $endorsementResponse->setStatus(EndorsementResponseStatus::DISPUTE_REJECTED);
                break;
            default:
                $endorsementResponse->setStatus(EndorsementResponseStatus::DISPUTE_PROGRESS);
        }

        $this->dm->persist($endorsementResponse);

        $this->dm->flush();
        return $original;
    }

    /**
     * @param EndorsementDispute $endorsementDispute
     * @return string
     */
    public function getAdminDisputeUri(EndorsementDispute $endorsementDispute)
    {
        return $this->frontEndUiUrl . $this->frontEndAdminDisputeUri . '/' .$endorsementDispute->getId();
    }
}
