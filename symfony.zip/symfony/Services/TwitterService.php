<?php

namespace AppBundle\Services;

use Abraham\TwitterOAuth\TwitterOAuth;
use Symfony\Component\HttpFoundation\Response;

class TwitterService
{
    private $twitterClientId;
    private $twitterClientSecret;

    public function __construct(string $twitterClientId, string $twitterClientSecret)
    {
        $this->twitterClientId = $twitterClientId;
        $this->twitterClientSecret = $twitterClientSecret;
    }

    public function post(string $token, string $tokenSecret, string $status, string $image = null, string $video = null)
    {
        $parameters = [
            'status' => $status
        ];

        $twitter = $this->connect($token, $tokenSecret);
        $twitter->setTimeouts(100000, 100000); // Effectively disable timeout because it's annoying.

        if ($image) {
            $media = $twitter->upload('media/upload', ['media' => $image]);
        }

        if ($video) {
            //split the video url to get the file name
            $split = explode("/", $video);
            $file_name = end($split);

            // Download remote video file on server
            $this->downloadFile($file_name, $video);

            $media_type = $this->getMimeType($file_name);
            $media = $twitter->upload('media/upload', array('media' => $file_name, 'media_type' => $media_type), true);
        }

        if (isset($media)) {
            $parameters['media_ids'] = [$media->media_id_string];
            $post = $twitter->post('statuses/update', $parameters);

            return $twitter->getLastHttpCode() == Response::HTTP_OK ? $post->id_str : false;
        }

        return false;
    }

    private function downloadFile($filename, $video)
    {
        file_put_contents($filename, file_get_contents($video));
    }

    private function getMimeType($file)
    {
        if (function_exists('finfo_open')) {
            $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($fileInfo, $file);
            finfo_close($fileInfo);
        } else {
            $mimeType = mime_content_type($file);
        }

        if (empty($mimeType)) {
            $mimeType = 'application/octet-stream';
        }

        return $mimeType;
    }

    private function connect(string $token, string $tokenSecret)
    {
        return new TwitterOAuth($this->twitterClientId, $this->twitterClientSecret, $token, $tokenSecret);
    }
}
