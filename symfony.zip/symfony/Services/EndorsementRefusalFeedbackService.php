<?php

namespace AppBundle\Services;

use AppBundle\Document\EndorsementRefusalFeedback;
use Doctrine\ODM\MongoDB\DocumentManager;

class EndorsementRefusalFeedbackService
{
    /** DocumentManager $dm */
    private $dm;

    /**
     * EndorsementRefusalFeedbackService constructor.
     * @param DocumentManager $dm
     */
    public function __construct(DocumentManager $dm)
    {
        $this->dm = $dm;
    }

    /**
     * @param EndorsementRefusalFeedback $endorsementRefusalFeedback
     * @return EndorsementRefusalFeedback
     */
    public function create(EndorsementRefusalFeedback $endorsementRefusalFeedback)
    {
        $endorsementRefusalFeedback->setTimestamp(new \DateTime("now"));
        $endorsementRefusalFeedback->setEndorsementRequest(
            $this->dm->getReference(
                'AppBundle:EndorsementRequest',
                $endorsementRefusalFeedback->getEndorsementRequest()->getId()
            )
        );

        return $this->save($endorsementRefusalFeedback);
    }

    /**
     * @param EndorsementRefusalFeedback $endorsementRefusalFeedback
     * @return EndorsementRefusalFeedback
     */
    private function save(EndorsementRefusalFeedback $endorsementRefusalFeedback)
    {
        $this->dm->persist($endorsementRefusalFeedback);
        $this->dm->flush();

        return $endorsementRefusalFeedback;
    }
}
