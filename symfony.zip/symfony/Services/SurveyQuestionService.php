<?php

namespace AppBundle\Services;

use AppBundle\Entity\QuestionType\CommentBox;
use AppBundle\Entity\QuestionType\Dropdown;
use AppBundle\Entity\QuestionType\MultipleChoice;
use AppBundle\Entity\QuestionType\PromoterIndex;
use AppBundle\Entity\QuestionType\SingleTextbox;
use AppBundle\Entity\QuestionType\StarRating;
use AppBundle\Entity\SurveyQuestion;
use Doctrine\ORM\EntityManager;

class SurveyQuestionService
{
    /** @var EntityManager $em */
    private $em;

    /**
     * SurveyQuestionService constructor.
     * @param EntityManager $em
     */
    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    /**
     * @param SurveyQuestion $surveyQuestion
     */
    public function sort(SurveyQuestion $surveyQuestion)
    {
        $repo = $this->em->getRepository(SurveyQuestion::class);
        $q = $repo
            ->createQueryBuilder('sq')
            ->where('sq.survey = :survey_id')
            ->setParameter('survey_id', $surveyQuestion->getSurvey()->getId())
            ->andWhere('sq.position >= :position')
            ->setParameter('position', $surveyQuestion->getPosition())
            ->orderBy('sq.position')
            ->getQuery()
            ->getResult();

        if (count($q)) {
            foreach ($q as $question) {
                /** @var $question SurveyQuestion */
                $question->setPosition($question->getPosition() + 1);
                $this->em->persist($question);
            }
        }

        $this->em->flush();
    }

    /**
     * @param array $array
     * @return CommentBox|Dropdown|MultipleChoice|SingleTextbox|StarRating|PromoterIndex|null
     */
    public function createQuestionFromArray(array $array)
    {
        if (!array_key_exists("type", $array)) {
            return null;
        }

        if (array_key_exists("type", $array)) {
            $array["question"] = $array["prompt"];
        }

        switch ($array['type']) {
            case SurveyQuestion::TYPE_COMMENT_BOX:
                return new CommentBox($array, false);
            case SurveyQuestion::TYPE_DROPDOWN:
                return new Dropdown($array, false);
            case SurveyQuestion::TYPE_MULTIPLE_CHOICE:
                return new MultipleChoice($array, false);
            case SurveyQuestion::TYPE_SINGLE_TEXTBOX:
                return new SingleTextbox($array, false);
            case SurveyQuestion::TYPE_STAR_RATING:
                return new StarRating($array, false);
            case SurveyQuestion::TYPE_PROMOTER_INDEX:
                return new PromoterIndex($array, false);
            default:
                return null;
        }
    }

    /**
     * @param SurveyQuestion $surveyQuestion
     * @return SurveyQuestion
     */
    public function save(SurveyQuestion $surveyQuestion)
    {
        $this->em->persist($surveyQuestion);
        $this->em->flush();

        return $surveyQuestion;
    }

    /**
     * @param int $id
     * @return SurveyQuestion
     */
    public function findById($id)
    {
        return $this->em->getRepository(SurveyQuestion::class)->find($id);
    }
}
