<?php

namespace AppBundle\Services;

use AppBundle\Entity\CompanySettings;
use Doctrine\ORM\EntityManager;

/**
 * Class CompanySettingsService
 * @package AppBundle\Services
 */
class CompanySettingsService
{
    /** @var EntityManager $em */
    private $em;

    /**
     * CompanySettingsService constructor.
     * @param EntityManager $em
     */
    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    public function createCompanySettings(CompanySettings $settings)
    {
        $settings = $this->save($settings);

        return $settings;
    }

    public function updateCompanySettings(CompanySettings $id, CompanySettings $settings)
    {
        $id->setSuppressUserProfiles($settings->getSuppressUserProfiles());
        $id->setOverrideProfileDescription($settings->getOverrideProfileDescription());
        $id->setOverrideFeedWidget($settings->getOverrideFeedWidget());
        $id->setOverridePushTargets($settings->getOverridePushTargets());
        $id->setEnableGlobalSurvey($settings->getEnableGlobalSurvey());
        $id->setSuppressSocialImages($settings->getSuppressSocialImages());

        return $this->save($id);
    }

    private function save(CompanySettings $companySettings)
    {
        $this->em->persist($companySettings);
        $this->em->flush();

        return $companySettings;
    }
}
