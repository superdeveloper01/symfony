<?php

namespace AppBundle\Services;

/**
 * Class WixService
 * @package AppBundle\Services
 */
class WixService
{
    private $wixAppSecret;

    public function __construct($wixAppSecret)
    {
        $this->wixAppSecret = $wixAppSecret;
    }

    /**
     * @param string $signature
     * @return bool | \stdClass
     */
    public function parseWixSignature($signature)
    {
        list($code, $data) = explode('.', $signature);

        if (base64_decode(strtr( $code, "-_", "+/" )) != hash_hmac("sha256", $data, $this->wixAppSecret, true)) {
            return false;
        }

        if (($response = json_decode(base64_decode($data))) === null) {
            return false;
        }

        return $response;
    }

    /**
     * @param \stdClass $data
     * @return bool
     */
    public function isWixSiteOwner(\stdClass $data)
    {
        if (!property_exists($data, 'siteOwnerId') || !property_exists($data, 'uid')) {
            return false;
        }
        
        return $data->siteOwnerId == $data->uid;
    }
    
    public function grantOwnerAccess($signature)
    {
        $data = $this->parseWixSignature($signature);
        
        if (!$data) {
            return false;
        }
        
        return $this->isWixSiteOwner($data);
    }
}