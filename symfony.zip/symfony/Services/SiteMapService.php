<?php

namespace AppBundle\Services;

use AppBundle\Entity\BranchProfile;
use AppBundle\Entity\CompanyProfile;
use AppBundle\Entity\StaticPage;
use AppBundle\Entity\UserProfile;
use Doctrine\ORM\EntityManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

class SiteMapService
{
    /** @var ContainerInterface */
    private $container;

    /** @var EntityManager */
    private $em;

    /**
     * SiteMapService constructor.
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
        $this->em = $container->get('doctrine.orm.entity_manager');
    }

    public function generateSiteMap()
    {
        $xml = new \SimpleXMLElement('<urlset/>');
        $xml->addAttribute('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');

        $data = [];

        $staticPages = $this->em->getRepository('AppBundle:StaticPage')->findAll();

        /** @var StaticPage $staticPage */
        foreach ($staticPages as $staticPage) {
            $data[] = [
                'loc' => $this->getStaticPageUrl($staticPage),
                'changefreq' => $staticPage->getChangeFrequency(),
                'priority' => number_format($staticPage->getPriority(), 1),
                'lastmod' => $staticPage->getLastModified()->format('Y-m-d')
            ];
        }

        $companyProfiles = $this->getCompanyProfiles();

        foreach ($companyProfiles as $key => $companyProfile) {
            $data[] = [
                'loc' => $this->getCompanyProfileUrl($companyProfile),
                'changefreq' => 'monthly',
                'priority' => .8
            ];
        }

        $branchProfiles = $this->getBranchProfiles();

        foreach ($branchProfiles as $branchProfile) {
            $data[] = [
                'loc' => $this->getBranchProfileUrl($branchProfile),
                'changefreq' => 'monthly',
                'priority' => .8,
            ];
        }

        $userProfiles = $this->getUserProfiles();

        /** @var UserProfile $userProfile */
        foreach ($userProfiles as $userProfile) {
            $branch = $userProfile->getUser()->getBranch();

            if ($branch && $branch->getCompany()) {
                if (!$branch->getCompany()->getSettings() ||
                    !$branch->getCompany()->getSettings()->getSuppressUserProfiles()
                ) {
                    $data[] = [
                        'loc' => $this->getUserProfileUrl($userProfile),
                        'changefreq' => 'monthly',
                        'priority' => .8,
                    ];
                }
            }
        }

        $xml = $this->arrayToXml($xml, $data);

        $this->createSitemap($xml);

        return true;
    }

    /**
     * @param \SimpleXMLElement $object
     * @param array $data
     * @return \SimpleXMLElement
     */
    private function arrayToXml(\SimpleXMLElement $object, array $data)
    {
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $newObject = $object->addChild('url');
                $this->arrayToXml($newObject, $value);
            } else {
                $object->addChild($key, $value);
            }
        }

        return $object;
    }

    /**
     * @return mixed
     */
    private function getUserProfiles()
    {
        $userProfileRepo = $this->em->getRepository(UserProfile::class);

        return $userProfileRepo
            ->createQueryBuilder('profile')
            ->join('profile.user', 'user')
            ->where('user.active = 1')
            ->getQuery()
            ->getResult();
    }

    /**
     * @return mixed
     */
    private function getBranchProfiles()
    {
        $branchProfileRepo = $this->em->getRepository(BranchProfile::class);

        return $branchProfileRepo
            ->createQueryBuilder('profile')
            ->join('profile.branch', 'branch')
            ->where('branch.active = 1')
            ->getQuery()
            ->getResult();
    }

    /**
     * @return mixed
     */
    private function getCompanyProfiles()
    {
        $companyProfileRepo = $this->em->getRepository(CompanyProfile::class);

        return $companyProfileRepo
            ->createQueryBuilder('profile')
            ->join('profile.company', 'company')
            ->where('company.active = 1')
            ->getQuery()
            ->getResult();
    }

    /**
     * @param StaticPage $staticPage
     * @return string
     */
    private function getStaticPageUrl(StaticPage $staticPage)
    {
        return $this->container->getParameter('ng') . $staticPage->getLocation();
    }

    /**
     * @param CompanyProfile $companyProfile
     * @return string
     */
    private function getCompanyProfileUrl(CompanyProfile $companyProfile)
    {
        return $this->container->getParameter('ng') .
            '/company/' . $companyProfile->getCompany()->getSlug();
    }

    /**
     * @param BranchProfile $branchProfile
     * @return string
     */
    private function getBranchProfileUrl(BranchProfile $branchProfile)
    {
        return $this->container->getParameter('ng') .
            '/branch/' . $branchProfile->getBranch()->getSlug();
    }

    /**
     * @param UserProfile $userProfile
     * @return string
     */
    private function getUserProfileUrl(UserProfile $userProfile)
    {
        return $this->container->getParameter('ng') .
            '/user/' . $userProfile->getUser()->getSlug();
    }

    /**
     * @param \SimpleXMLElement $xml
     */
    private function createSitemap(\SimpleXMLElement $xml)
    {
        $file = 'web/sitemap.xml';

        $handle = fopen($file, 'w');
        fwrite($handle, $xml->asXML());
        fclose($handle);
    }
}
