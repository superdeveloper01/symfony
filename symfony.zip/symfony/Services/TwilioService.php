<?php

namespace AppBundle\Services;

use AppBundle\Document\EndorsementRequest;
use AppBundle\Entity\Survey;
use Doctrine\ORM\EntityManager;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Twilio\Rest\Client;

class TwilioService
{
    /** @var EntityManager $em */
    private $em;

    /** @var string $twilioNumber */
    private $twilioNumber;

    /** @var Client $client */
    private $client;

    /** @var string $callbackUrl */
    private $callbackUrl;

    /** @var StatisticService $statService */
    private $statService;

    public function __construct(
        ContainerInterface $container,
        string $twilioAccountSid,
        string $twilioToken,
        string $twilioNumber,
        string $apiUrl
    ) {
        $this->em = $container->get('doctrine.orm.entity_manager');
        $this->twilioNumber = $twilioNumber;
        $this->client = new Client($twilioAccountSid, $twilioToken);
        $this->callbackUrl = $apiUrl . '/twilio/event';
        $this->statService = $container->get('statistic_service');
    }

    /**
     * @param string $to
     * @param string $body
     * @param string $endorsementRequestId
     * @return bool
     */
    public function sendText(string $to, string $body, string $endorsementRequestId)
    {
        try {
            $this->client->messages->create(
                $to,
                [
                    'from' => $this->twilioNumber,
                    'body' => $body,
                    'statusCallback' => $this->callbackUrl . '/' . $endorsementRequestId
                ]
            );

            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @param EndorsementRequest $endorsementRequest
     * @param string $status
     * @return bool
     */
    public function recordStatistic(EndorsementRequest $endorsementRequest, string $status)
    {
        /** @var Survey $survey */
        $survey = $this->em->getRepository(Survey::class)->find($endorsementRequest->getSurveyId());

        if (!$survey) {
            return false;
        }

        switch ($status) {
            case 'delivered':
                $this->statService->recordEndorsementRequestDelivered($survey->getUser());
                break;
            case 'failed':
                $this->statService->recordEndorsementRequestFailed($survey->getUser());
                break;
        }

        return true;
    }
}
