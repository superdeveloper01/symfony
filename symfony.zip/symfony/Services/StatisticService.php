<?php

namespace AppBundle\Services;

use AppBundle\Document\EndorsementRefusalFeedback;
use AppBundle\Document\EndorsementRequest;
use AppBundle\Document\EndorsementResponse;
use AppBundle\Document\Statistic\BranchProfilePageView;
use AppBundle\Document\Statistic\BranchProfileSurveyLinkClick;
use AppBundle\Document\Statistic\CompanyProfilePageView;
use AppBundle\Document\Statistic\CompanyProfileSurveyLinkClick;
use AppBundle\Document\Statistic\EndorsementRequestDelivered;
use AppBundle\Document\Statistic\EndorsementRequestFailed;
use AppBundle\Document\Statistic\EndorsementRequestLinkClicked;
use AppBundle\Document\Statistic\EndorsementRequestOpened;
use AppBundle\Document\Statistic\EndorsementRequestSent;
use AppBundle\Document\Statistic\EndorsementResponseReceived;
use AppBundle\Document\Statistic\ReferralReceived;
use AppBundle\Document\Statistic\Share;
use AppBundle\Document\Statistic\UserProfilePageView;
use AppBundle\Document\Statistic\UserProfileSurveyLinkClick;
use AppBundle\Entity\Branch;
use AppBundle\Entity\Company;
use AppBundle\Entity\Survey;
use AppBundle\Entity\User;
use AppBundle\Repository\Statistic\AbstractBranchStatisticRepository;
use AppBundle\Repository\Statistic\AbstractCompanyStatisticRepository;
use AppBundle\Repository\Statistic\AbstractStatisticRepository;
use AppBundle\Repository\Statistic\AbstractUserStatisticRepository;
use AppBundle\Repository\Statistic\BranchProfilePageViewRepository;
use AppBundle\Repository\Statistic\BranchProfileSurveyLinkClickRepository;
use AppBundle\Repository\Statistic\CompanyProfilePageViewRepository;
use AppBundle\Repository\Statistic\CompanyProfileSurveyLinkClickRepository;
use AppBundle\Repository\Statistic\EndorsementRequestDeliveredRepository;
use AppBundle\Repository\Statistic\EndorsementRequestFailedRepository;
use AppBundle\Repository\Statistic\EndorsementRequestLinkClickedRepository;
use AppBundle\Repository\Statistic\EndorsementRequestOpenedRepository;
use AppBundle\Repository\Statistic\EndorsementRequestSentRepository;
use AppBundle\Repository\Statistic\EndorsementResponseReceivedRepository;
use AppBundle\Repository\Statistic\ReferralReceivedRepository;
use AppBundle\Repository\Statistic\ShareRepository;
use AppBundle\Repository\Statistic\UserProfilePageViewRepository;
use AppBundle\Repository\Statistic\UserProfileSurveyLinkClickRepository;
use AppBundle\Utilities\UserUtilities;
use Doctrine\ODM\MongoDB\DocumentManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class StatisticService
 * @package AppBundle\Services
 */
class StatisticService
{
    const TYPE_ENDORSEMENTS_REQUESTED           = 'endorsements_requested';
    const TYPE_ENDORSEMENTS_RECEIVED            = 'endorsements_received';
    const TYPE_SHARES                           = 'shares';
    const TYPE_PROFILE_PAGE_VIEWS               = 'profile_page_views';
    const TYPE_ENDORSEMENT_REQUESTS_DELIVERED   = 'endorsement_requests_delivered';
    const TYPE_ENDORSEMENT_REQUESTS_OPENED      = 'endorsement_requests_opened';
    const TYPE_ENDORSEMENT_REQUESTS_STARTED     = 'endorsement_requests_started';
    const TYPE_RATING                           = 'rating';
    const TYPE_PROMOTER_INDEX                   = 'promoterindex';

    /** @var DocumentManager */
    private $dm;

    /** @var ContainerInterface */
    private $container;

    /**
     * StatisticService constructor.
     * @param DocumentManager $dm
     */
    public function __construct(DocumentManager $dm, ContainerInterface $container)
    {
        $this->dm = $dm;
        $this->container = $container;
    }

    /**
     * @param string $type
     * @param \DateTime $startDate
     * @param \DateTime $endDate
     * @param string $interval
     * @param string $segment
     * @param int $segmentId
     * @return array
     */
    public function getStatsInBuckets(
        string $type,
        \DateTime $startDate,
        \DateTime $endDate,
        string $interval,
        string $segment,
        int $segmentId
    ) {
        $data = [];
        $repo = $this->getRepoByStatType($type, $segment);
        $em = $this->container->get('doctrine.orm.entity_manager');

        if (self::TYPE_RATING == $type || self::TYPE_PROMOTER_INDEX == $type) {
            switch ($segment) {
                case 'user':
                    /** @var User $user */
                    $user = $em->getRepository(User::class)->find($segmentId);
                    break;
                case 'branch':
                    /** @var Branch $branch */
                    $branch = $em->getRepository(Branch::class)->find($segmentId);
                    break;
                default:
                    /** @var Company $company */
                    $company = $em->getRepository(Company::class)->find($segmentId);
            }
        }

        if (!$repo) {
            return $data;
        }

        $buckets = $this->getBuckets($startDate, $endDate, $interval);

        /** @var \DateTime $startDate */
        foreach ($buckets as $startDate) {
            $endDate = new \DateTime($startDate->format('Y-m-d'));

            if ($repo instanceof AbstractStatisticRepository) {
                $data[$startDate->format('Y-m-d')] = $repo->filteredCount(
                    ($segment == 'user') ? $segmentId : null,
                    ($segment == 'branch') ? $segmentId : null,
                    ($segment == 'company') ? $segmentId : null,
                    $startDate,
                    $endDate->modify('+1 ' . $interval)
                );
            }

            if ($repo instanceof AbstractUserStatisticRepository) {
                $data[$startDate->format('Y-m-d')] = $repo->filteredCount(
                    $segmentId,
                    $startDate,
                    $endDate->modify('+1 ' . $interval)
                );
            }

            if ($repo instanceof AbstractBranchStatisticRepository) {
                $data[$startDate->format('Y-m-d')] = $repo->filteredCount(
                    $segmentId,
                    $startDate,
                    $endDate->modify('+1 ' . $interval)
                );
            }

            if ($repo instanceof AbstractCompanyStatisticRepository) {
                $data[$startDate->format('Y-m-d')] = $repo->filteredCount(
                    $segmentId,
                    $startDate,
                    $endDate->modify('+1 ' . $interval)
                );
            }

            if ('rating' == $type && isset($user)) {
                $data[$startDate->format('Y-m-d')] = $this->calculateAverageScoreByUser(
                    $user,
                    $startDate,
                    $endDate->modify('+1 ' . $interval)
                );
            }

            if ('rating' == $type && isset($branch)) {
                $data[$startDate->format('Y-m-d')] = $this->calculateAverageScoreByBranch(
                    $branch,
                    $startDate,
                    $endDate->modify('+1 ' . $interval)
                );
            }

            if ('rating' == $type && isset($company)) {
                $data[$startDate->format('Y-m-d')] = $this->calculateAverageScoreByCompany(
                    $company,
                    $startDate,
                    $endDate->modify('+1 ' . $interval)
                );
            }

            if ('promoterindex' == $type && isset($user)) {
                $data[$startDate->format('Y-m-d')] = $this->calculateAveragePromoterIndexByUser(
                    $user,
                    $startDate,
                    $endDate->modify('+1 ' . $interval)
                );
            }

            if ('promoterindex' == $type && isset($branch)) {
                $data[$startDate->format('Y-m-d')] = $this->calculateAveragePromoterIndexByBranch(
                    $branch,
                    $startDate,
                    $endDate->modify('+1 ' . $interval)
                );
            }

            if ('promoterindex' == $type && isset($company)) {
                $data[$startDate->format('Y-m-d')] = $this->calculateAveragePromoterIndexByCompany(
                    $company,
                    $startDate,
                    $endDate->modify('+1 ' . $interval)
                );
            }
        }

        return $data;
    }

    public function getSentimentStatsInBuckets(
        \DateTime $startDate,
        \DateTime $endDate,
        string $interval,
        string $segment,
        int $segmentId
    ) {
        $data = [];
        $surveyIds = [];
        $em = $this->container->get('doctrine.orm.entity_manager');

        switch ($segment) {
            case 'user':
                /** @var User $user */
                $user = $em->getRepository(User::class)->find($segmentId);
                break;
            case 'branch':
                /** @var Branch $branch */
                $branch = $em->getRepository(Branch::class)->find($segmentId);
                break;
            default:
                /** @var Company $company */
                $company = $em->getRepository(Company::class)->find($segmentId);
        }

        if (isset($user)) {
            $surveyIds = $em->getRepository(Survey::class)->getSentimentSurveyIdsByUsers([$user]);
        }

        if (isset($branch)) {
            $users = $em->getRepository(User::class)->getUsersByBranch($branch);
            $surveyIds = $em->getRepository(Survey::class)->getSentimentSurveyIdsByUsers($users);
        }

        if (isset($company)) {
            $users = $em->getRepository(User::class)->getUsersByCompany($company);
            $surveyIds = $em->getRepository(Survey::class)->getSentimentSurveyIdsByUsers($users);
        }

        $buckets = $this->getBuckets($startDate, $endDate, $interval);

        /** @var \DateTime $startDate */
        foreach ($buckets as $startDate) {
            $endDate = new \DateTime($startDate->format('Y-m-d'));
            $endDate = $endDate->modify('+1 ' . $interval);

            $endorsementRequests = $this->dm->getRepository(EndorsementRequest::class)->getSentimentRequestsDelivered(
                $surveyIds,
                $startDate,
                $endDate,
                false
            );

            $endorsementRequestIds = [];

            /** @var EndorsementRequest $endorsementRequest */
            foreach ($endorsementRequests as $endorsementRequest) {
                $endorsementRequestIds[] = $endorsementRequest->getId();
            }

            $data[$startDate->format('Y-m-d')] = [
                'delivered' => $this->dm->getRepository(EndorsementRequest::class)->getSentimentRequestsDelivered(
                    $surveyIds,
                    $startDate,
                    $endDate,
                    true
                ),
                'opened' => $this->dm->getRepository(EndorsementRequest::class)->getSentimentRequestsOpened(
                    $surveyIds,
                    $startDate,
                    $endDate,
                    true
                ),
                'yes' => count(
                    $this->dm->getRepository(EndorsementResponse::class)->getEndorsementsByRequestIds(
                        $endorsementRequestIds,
                        $startDate,
                        $endDate
                    )
                ),
                'no' => count(
                    $this->dm->getRepository(EndorsementRefusalFeedback::class)->getRefusalsByRequestIds(
                        $endorsementRequestIds,
                        $startDate,
                        $endDate
                    )
                ),
            ];
        }

        return $data;
    }

    /**
     * @param \DateTime $startDate
     * @param \DateTime $endDate
     * @param string $segment
     * @param int $segmentId
     * @return array
     */
    public function getAggregateRating(
        \DateTime $startDate,
        \DateTime $endDate,
        string $segment,
        int $segmentId
    ) {
        $data = [];

        $em = $this->container->get('doctrine.orm.entity_manager');

        switch ($segment) {
            case 'user':
                /** @var User $user */
                $user = $em->getRepository(User::class)->find($segmentId);
                if ($user) {
                    $data['aggregate_rating'] = $this->calculateAverageScoreByUser(
                        $user,
                        $startDate,
                        $endDate->modify('+1 day')
                    );
                    return $data;
                }
                break;
            case 'branch':
                /** @var Branch $branch */
                $branch = $em->getRepository(Branch::class)->find($segmentId);
                if ($branch) {
                    $data['aggregate_rating'] = $this->calculateAverageScoreByBranch(
                        $branch,
                        $startDate,
                        $endDate->modify('+1 day')
                    );
                    return $data;
                }
                break;
            default:
                /** @var Company $company */
                $company = $em->getRepository(Company::class)->find($segmentId);
                if ($company) {
                    $data['aggregate_rating'] = $this->calculateAverageScoreByCompany(
                        $company,
                        $startDate,
                        $endDate->modify('+1 day')
                    );
                    return $data;
                }
                break;
        }

        return $data;
    }

    /**
     * @param User $user
     * @return EndorsementRequestSent
     */
    public function recordEndorsementRequestSent(User $user, \DateTime $timestamp = null)
    {
        $stat = new EndorsementRequestSent(UserUtilities::getUserBranchAndCompanyIds($user));

        if (null !== $timestamp) {
            $stat->setCreationDate($timestamp);
        }

        /** @var EndorsementRequestSentRepository $repo */
        $repo = $this->dm->getRepository(EndorsementRequestSent::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param User $user
     * @return EndorsementRequestDelivered
     */
    public function recordEndorsementRequestDelivered(User $user, \DateTime $timestamp = null)
    {
        $stat = new EndorsementRequestDelivered(UserUtilities::getUserBranchAndCompanyIds($user));

        if (null !== $timestamp) {
            $stat->setCreationDate($timestamp);
        }

        /** @var EndorsementRequestDeliveredRepository $repo */
        $repo = $this->dm->getRepository(EndorsementRequestDelivered::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param User $user
     * @return EndorsementRequestFailed
     */
    public function recordEndorsementRequestFailed(User $user, \DateTime $timestamp = null)
    {
        $stat = new EndorsementRequestFailed(UserUtilities::getUserBranchAndCompanyIds($user));

        if (null !== $timestamp) {
            $stat->setCreationDate($timestamp);
        }

        /** @var EndorsementRequestFailedRepository $repo */
        $repo = $this->dm->getRepository(EndorsementRequestFailed::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param User $user
     * @return EndorsementRequestOpened
     */
    public function recordEndorsementRequestOpened(User $user, \DateTime $timestamp = null)
    {
        $stat = new EndorsementRequestOpened(UserUtilities::getUserBranchAndCompanyIds($user));

        if (null !== $timestamp) {
            $stat->setCreationDate($timestamp);
        }

        /** @var EndorsementRequestOpenedRepository $repo */
        $repo = $this->dm->getRepository(EndorsementRequestOpened::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param User $user
     * @return EndorsementRequestLinkClicked
     */
    public function recordEndorsementRequestLinkClicked(User $user, \DateTime $timestamp = null)
    {
        $stat = new EndorsementRequestLinkClicked(UserUtilities::getUserBranchAndCompanyIds($user));

        if (null !== $timestamp) {
            $stat->setCreationDate($timestamp);
        }

        /** @var EndorsementRequestLinkClickedRepository $repo */
        $repo = $this->dm->getRepository(EndorsementRequestLinkClicked::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param User $user
     * @return EndorsementResponseReceived
     */
    public function recordEndorsementResponseReceived(User $user, \DateTime $timestamp = null)
    {
        $stat = new EndorsementResponseReceived(UserUtilities::getUserBranchAndCompanyIds($user));

        if (null !== $timestamp) {
            $stat->setCreationDate($timestamp);
        }

        /** @var EndorsementResponseReceivedRepository $repo */
        $repo = $this->dm->getRepository(EndorsementResponseReceived::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param User $user
     * @return Share
     */
    public function recordShare(User $user)
    {
        $stat = new Share(UserUtilities::getUserBranchAndCompanyIds($user));

        /** @var ShareRepository $repo */
        $repo = $this->dm->getRepository(Share::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param User $user
     * @return UserProfilePageView
     */
    public function recordUserProfilePageView(User $user)
    {
        $stat = new UserProfilePageView(['userId' => $user->getId()]);

        /** @var UserProfilePageViewRepository $repo */
        $repo = $this->dm->getRepository(UserProfilePageView::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param User $user
     * @return UserProfileSurveyLinkClick
     */
    public function recordUserProfileSurveyLinkClick(User $user)
    {
        $stat = new UserProfileSurveyLinkClick(['userId' => $user->getId()]);

        /** @var UserProfileSurveyLinkClickRepository $repo */
        $repo = $this->dm->getRepository(UserProfileSurveyLinkClick::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param Branch $branch
     * @return BranchProfilePageView
     */
    public function recordBranchProfilePageView(Branch $branch)
    {
        $stat = new BranchProfilePageView(['branchId' => $branch->getId()]);

        /** @var BranchProfilePageViewRepository $repo */
        $repo = $this->dm->getRepository(BranchProfilePageView::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param Branch $branch
     * @return BranchProfileSurveyLinkClick
     */
    public function recordBranchProfileSurveyLinkClick(Branch $branch)
    {
        $stat = new BranchProfileSurveyLinkClick(['branchId' => $branch->getId()]);

        /** @var BranchProfileSurveyLinkClickRepository $repo */
        $repo = $this->dm->getRepository(BranchProfileSurveyLinkClick::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param Company $company
     * @return CompanyProfilePageView
     */
    public function recordCompanyProfilePageView(Company $company)
    {
        $stat = new CompanyProfilePageView(['companyId' => $company->getId()]);

        /** @var CompanyProfilePageViewRepository $repo */
        $repo = $this->dm->getRepository(CompanyProfilePageView::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param Company $company
     * @return CompanyProfileSurveyLinkClick
     */
    public function recordCompanyProfileSurveyLinkClick(Company $company)
    {
        $stat = new CompanyProfileSurveyLinkClick(['companyId' => $company->getId()]);

        /** @var CompanyProfileSurveyLinkClickRepository $repo */
        $repo = $this->dm->getRepository(CompanyProfileSurveyLinkClick::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param User $user
     * @return ReferralReceived
     */
    public function recordReferralReceived(User $user)
    {
        $stat = new ReferralReceived(UserUtilities::getUserBranchAndCompanyIds($user));

        /** @var ReferralReceivedRepository $repo */
        $repo = $this->dm->getRepository(ReferralReceived::class);
        $repo->save($stat);

        return $stat;
    }

    /**
     * @param User $user
     * @param $class
     * @return int
     */
    public function countUserStats(User $user, $class)
    {
        $repo = $this->dm->getRepository($class);

        if (method_exists($repo, 'countByUser')) {
            return $repo->countByUser($user);
        }

        return 0;
    }

    /**
     * @param Branch $branch
     * @param $class
     * @return int
     */
    public function countBranchStats(Branch $branch, $class)
    {
        $repo = $this->dm->getRepository($class);

        if (method_exists($repo, 'countByBranch')) {
            return $repo->countByBranch($branch);
        }

        return 0;
    }

    /**
     * @param Company $company
     * @param $class
     * @return int
     */
    public function countCompanyStats(Company $company, $class)
    {
        $repo = $this->dm->getRepository($class);

        if (method_exists($repo, 'countByCompany')) {
            return $repo->countByCompany($company);
        }

        return 0;
    }

    /**
     * @param User $user
     * @return float|int
     */
    public function calculateAverageScoreByUser(
        User $user,
        \DateTime $startDate = null,
        \DateTime $endDate = null
    ) {
        // Find surveys for the user
        $eligibleSurveys = $this->container->get('survey_service')->getSurveysByUser($user, null);

        return $this->calculateAverageScore($eligibleSurveys, $startDate, $endDate);
    }

    /**
     * @param User $user
     * @return int
     */
    public function countScorableEndorsementsByUser(User $user)
    {
        $eligibleSurveys = $this->container->get('survey_service')->getSurveysByUser($user);
        $scorableEndorsements = $this->getScorableEndorsements($eligibleSurveys);

        return ($scorableEndorsements) ? count($scorableEndorsements) : 0;
    }

    /**
     * @param Branch $branch
     * @return float|int
     */
    public function calculateAverageScoreByBranch(
        Branch $branch,
        \DateTime $startDate = null,
        \DateTime $endDate = null
    ) {
        // Find surveys for the branch
        $eligibleSurveys = $this->container->get('survey_service')->getSurveysByBranch($branch, null);

        return $this->calculateAverageScore($eligibleSurveys, $startDate, $endDate);
    }

    /**
     * @param Branch $branch
     * @return int
     */
    public function countScorableEndorsementsByBranch(Branch $branch)
    {
        $eligibleSurveys = $this->container->get('survey_service')->getSurveysByBranch($branch);
        $scorableEndorsements = $this->getScorableEndorsements($eligibleSurveys);

        return ($scorableEndorsements) ? count($scorableEndorsements) : 0;
    }

    /**
     * @param Company $company
     * @return float|int
     */
    public function calculateAverageScoreByCompany(
        Company $company,
        \DateTime $startDate = null,
        \DateTime $endDate = null
    ) {
        // Find surveys for the company
        $eligibleSurveys = $this->container->get('survey_service')->getSurveysByCompany($company, null);

        return $this->calculateAverageScore($eligibleSurveys, $startDate, $endDate);
    }

    /**
     * @param Company $company
     * @return int
     */
    public function countScorableEndorsementsByCompany(Company $company)
    {
        $eligibleSurveys = $this->container->get('survey_service')->getSurveysByCompany($company);
        $scorableEndorsements = $this->getScorableEndorsements($eligibleSurveys);

        return ($scorableEndorsements) ? count($scorableEndorsements) : 0;
    }

    /**
     * @param User $user
     * @param \DateTime|null $startDate
     * @param \DateTime|null $endDate
     * @return float|int
     */
    public function calculateAveragePromoterIndexByUser(
        User $user,
        \DateTime $startDate = null,
        \DateTime $endDate = null
    ) {
        // Find surveys for the user
        $eligibleSurveys = $this->container->get('survey_service')->getSurveysByUser($user, null);

        return $this->calculateAveragePromoterIndex($eligibleSurveys, $startDate, $endDate);
    }

    /**
     * @param Branch $branch
     * @param \DateTime|null $startDate
     * @param \DateTime|null $endDate
     * @return float|int
     */
    public function calculateAveragePromoterIndexByBranch(
        Branch $branch,
        \DateTime $startDate = null,
        \DateTime $endDate = null
    ) {
        // Find surveys for the branch
        $eligibleSurveys = $this->container->get('survey_service')->getSurveysByBranch($branch, null);

        return $this->calculateAveragePromoterIndex($eligibleSurveys, $startDate, $endDate);
    }

    /**
     * @param Company $company
     * @param \DateTime|null $startDate
     * @param \DateTime|null $endDate
     * @return float|int
     */
    public function calculateAveragePromoterIndexByCompany(
        Company $company,
        \DateTime $startDate = null,
        \DateTime $endDate = null
    ) {
        $eligibleSurveys = $this->container->get('survey_service')->getSurveysByCompany($company, null);

        return $this->calculateAveragePromoterIndex($eligibleSurveys, $startDate, $endDate);
    }

    /**
     * @param string $type
     * @param string $segment
     * @return BranchProfilePageViewRepository|CompanyProfilePageViewRepository|EndorsementRequestSentRepository|EndorsementResponseReceivedRepository|ShareRepository|UserProfilePageViewRepository|bool|\Doctrine\ODM\MongoDB\DocumentRepository
     */
    private function getRepoByStatType(string $type, string $segment)
    {
        switch ($type) {
            case self::TYPE_ENDORSEMENTS_REQUESTED:
                return $this->dm->getRepository(EndorsementRequestSent::class);
            case self::TYPE_ENDORSEMENTS_RECEIVED:
                return $this->dm->getRepository(EndorsementResponseReceived::class);
            case self::TYPE_SHARES:
                return $this->dm->getRepository(Share::class);
            case self::TYPE_PROFILE_PAGE_VIEWS:
                if ($segment == 'user') {
                    return $this->dm->getRepository(UserProfilePageView::class);
                } elseif ($segment == 'branch') {
                    return $this->dm->getRepository(BranchProfilePageView::class);
                } else {
                    return $this->dm->getRepository(CompanyProfilePageView::class);
                }
                break;
            case self::TYPE_ENDORSEMENT_REQUESTS_DELIVERED:
                return $this->dm->getRepository(EndorsementRequestDelivered::class);
            case self::TYPE_ENDORSEMENT_REQUESTS_OPENED:
                return $this->dm->getRepository(EndorsementRequestOpened::class);
            case self::TYPE_ENDORSEMENT_REQUESTS_STARTED:
                return $this->dm->getRepository(EndorsementRequestLinkClicked::class);
            case self::TYPE_RATING:
            case self::TYPE_PROMOTER_INDEX:
                return true;
        }

        return false;
    }

    /**
     * @param \DateTime $startDate
     * @param \DateTime $endDate
     * @param string $interval
     * @return \DatePeriod
     */
    private function getBuckets(\DateTime $startDate, \DateTime $endDate, string $interval)
    {
        $endDate = $endDate->modify('+1 day');

        switch ($interval) {
            case 'day':
                $interval = new \DateInterval('P1D');
                break;
            case 'week':
                $interval = new \DateInterval('P7D');
                break;
            case 'month':
                $interval = new \DateInterval('P1M');
                break;
        }

        return new \DatePeriod($startDate, $interval, $endDate);
    }

    /**
     * @param array $eligibleSurveys
     * @return float|int
     */
    private function calculateAverageScore(
        array $eligibleSurveys,
        \DateTime $startDate = null,
        \DateTime $endDate = null
    ) {
        $endorsements = $this->getScorableEndorsements($eligibleSurveys, $startDate, $endDate);

        // No endorsements, no score
        if (!$endorsements) {
            return 0;
        }

        // Calculate and return the average
        $averageRating = 0;

        /** @var EndorsementResponse $endorsement */
        foreach ($endorsements as $endorsement) {
            $averageRating += $endorsement->getRating();
        }

        return $averageRating > 0 ? $averageRating / count($endorsements) : 0;
    }

    private function calculateAveragePromoterIndex(
        array $eligibleSurveys,
        \DateTime $startDate = null,
        \DateTime $endDate = null
    ) {
        $endorsements = $this->getNetPromoterEndorsements($eligibleSurveys, $startDate, $endDate);

        if (!$endorsements) {
            return 0;
        }

        $average = 0;

        /** @var EndorsementResponse $endorsement */
        foreach ($endorsements as $endorsement) {
            $average += $endorsement->getPromoterIndex();
        }

        return $average > 0 ? $average / count($endorsements) : 0;
    }

    /**
     * @param array $eligibleSurveys
     * @return int|mixed
     */
    private function getScorableEndorsements(
        array $eligibleSurveys,
        \DateTime $startDate = null,
        \DateTime $endDate = null
    ) {
        if (!count($eligibleSurveys)) {
            return 0;
        }

        $surveys = [];
        /** @var Survey $survey */
        foreach ($eligibleSurveys as $survey) {
            $surveys[] = $survey->getId();
        }

        // Get endorsement requests from Survey IDs; we need this query to connect the user to the endorsement response
        $endorsementRequests = $this->dm->getRepository('AppBundle:EndorsementRequest')
            ->createQueryBuilder()
            ->field('survey_id')
            ->in($surveys)
            ->getQuery()
            ->execute();

        // No endorsement requests, no score
        if (!$endorsementRequests) {
            return 0;
        }

        // Get responses that have a rating but are not disputed
        return $this->dm->getRepository(EndorsementResponse::class)->getScorableEndorsementResponses(
            $endorsementRequests,
            $startDate,
            $endDate
        );
    }

    private function getNetPromoterEndorsements(
        array $eligibleSurveys,
        \DateTime $startDate = null,
        \DateTime $endDate = null
    ) {
        if (!count($eligibleSurveys)) {
            return 0;
        }

        $surveys = [];
        /** @var Survey $survey */
        foreach ($eligibleSurveys as $survey) {
            $surveys[] = $survey->getId();
        }

        // Get endorsement requests from Survey IDs; we need this query to connect the user to the endorsement response
        $endorsementRequests = $this->dm->getRepository('AppBundle:EndorsementRequest')
            ->createQueryBuilder()
            ->field('survey_id')
            ->in($surveys)
            ->getQuery()
            ->execute();

        // No endorsement requests, no score
        if (!$endorsementRequests) {
            return 0;
        }

        // Get responses that have a rating but are not disputed
        return $this->dm->getRepository(EndorsementResponse::class)->getNetPromoterEndorsementResponses(
            $endorsementRequests,
            $startDate,
            $endDate
        );
    }
}
