<?php

namespace AppBundle\Services;

use Aws\Credentials\Credentials;
use Aws\ElasticTranscoder\ElasticTranscoderClient;

class AwsElasticTranscoderService
{
    /** @var string $awsAccessKeyId */
    private $awsAccessKeyId;

    /** @var string $awsAccessKeySecret */
    private $awsAccessKeySecret;

    /** @var string $videoEndorsementPipelineId */
    private $videoEndorsementPipelineId;

    /** @var string $videoEndorsementDirectory */
    private $videoEndorsementDirectory;

    /** @var string $videoEndorsementTranscodedDirectory */
    private $videoEndorsementTranscodedDirectory;

    /**
     * AwsElasticTranscoderService constructor.
     * @param string $awsAccessKeyId
     * @param string $awsAccessKeySecret
     * @param string $videoEndorsementPipelineId
     * @param string $videoEndorsementDirectory
     * @param string $videoEndorsementTranscodedDirectory
     */
    public function __construct(
        string $awsAccessKeyId,
        string $awsAccessKeySecret,
        string $videoEndorsementPipelineId,
        string $videoEndorsementDirectory,
        string $videoEndorsementTranscodedDirectory
    ) {
        $this->awsAccessKeyId = $awsAccessKeyId;
        $this->awsAccessKeySecret = $awsAccessKeySecret;
        $this->videoEndorsementPipelineId = $videoEndorsementPipelineId;
        $this->videoEndorsementDirectory = $videoEndorsementDirectory;
        $this->videoEndorsementTranscodedDirectory = $videoEndorsementTranscodedDirectory;
    }

    /**
     * @param string $filename
     * @param string $fileExtension
     * @return \Aws\Result
     */
    public function transcodeVideoEndorsementToMp4(
        string $filename,
        string $fileExtension
    ) {
        $client = $this->getETClient();

        return $client->createJob([
            'PipelineId' => $this->videoEndorsementPipelineId,
            'Input' => [
                'Key' => $this->videoEndorsementDirectory . '/' . $filename . $fileExtension,
            ],
            'Output' => [
                'Key' => $this->videoEndorsementTranscodedDirectory . '/' . $filename . '.mp4',
                'PresetId' => '1351620000001-100070',
                'ThumbnailPattern' => $this->videoEndorsementTranscodedDirectory . '/' . $filename . '-{count}'
            ]
        ]);
    }

    /**
     * @param null $awsAccessKeyId
     * @param null $awsAccessKeySecret
     * @return ElasticTranscoderClient
     */
    private function getETClient(string $awsAccessKeyId = null, string $awsAccessKeySecret = null)
    {
        $credentials = new Credentials(
            $awsAccessKeyId ? $awsAccessKeyId : $this->awsAccessKeyId,
            $awsAccessKeySecret ? $awsAccessKeySecret : $this->awsAccessKeySecret
        );

        return new ElasticTranscoderClient([
            'version'     => 'latest',
            'region'      => 'us-west-2',
            'credentials' => $credentials
        ]);
    }
}
