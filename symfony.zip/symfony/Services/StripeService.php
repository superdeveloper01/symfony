<?php

namespace AppBundle\Services;

use AppBundle\Entity\Stripe\Plan;
use AppBundle\Entity\Stripe\Source;
use AppBundle\Entity\Stripe\Subscription;
use AppBundle\Enumeration\FeatureAccessLevel;
use Doctrine\ORM\EntityManager;
use AppBundle\Entity\Stripe\Customer;
use AppBundle\Entity\User;
use Stripe;

class StripeService
{
    private $em;
    private $stripePrivateKey;

    public function __construct(EntityManager $em, $stripePrivateKey)
    {
        $this->em = $em;
        $this->stripePrivateKey = $stripePrivateKey;
    }

    /**
     * @param Customer $customer
     * @param User $user
     * @return User
     */
    public function postCustomer(Customer $customer, User $user)
    {
        $data = [
            'email' => $customer->getEmail(),
            'coupon' => $customer->getCoupon(),
            'plan' => $customer->getPlan(),
            'quantity' => $customer->getQuantity(),
            'trial_end' => $customer->getTrialEnd()
        ];

        if (!empty($customer->getSource())) {
            $data['source'] = $this->getSourceFromObject($customer->getSource());
        }

        $stripeCustomer = Stripe\Customer::create($data, $this->stripePrivateKey)->__toArray(true);

        $user->setStripeId($stripeCustomer['id']);

        if (null !== $customer->getPlan()) {
            $user->setPlan($this->getPlan($customer->getPlan()));
        }

        $this->em->persist($user);
        $this->em->flush();

        return $user;
    }

    /**
     * @param Customer $customer
     * @param User $user
     * @return User
     */
    public function putCustomer(Customer $customer, User $user)
    {
        $stripeCustomer = Stripe\Customer::retrieve($user->getStripeId(), $this->stripePrivateKey);

        if (null !== $customer->getCoupon()) {
            $stripeCustomer->coupon = $customer->getCoupon();
        }

        if (null !== $customer->getEmail()) {
            $stripeCustomer->email = $customer->getEmail();
        }

        if (null !== $customer->getPlan() && null !== $customer->getQuantity()) {
            $stripeCustomer->plan = $customer->getPlan();
            $stripeCustomer->quantity = $customer->getQuantity();
            
            $user->setPlan($this->getPlan($customer->getPlan()));
            $this->em->persist($user);
            $this->em->flush();
        }

        if (!empty($customer->getSource())) {
            $stripeCustomer->source = $this->getSourceFromObject($customer->getSource());
        }

        $stripeCustomer->save();

        return $user;
    }

    /**
     * @param User $user
     * @param Subscription $subscription
     * @return User
     */
    public function postSubscription(User $user, Subscription $subscription)
    {
        Stripe\Stripe::setApiKey($this->stripePrivateKey);

        $customer = Stripe\Customer::retrieve($user->getStripeId());

        $arr = [
            'plan' => $subscription->getPlan(),
            'quantity' => (int) $this->getSubscriptionQuantity($subscription),
        ];

        if (null !== $subscription->getCoupon()) {
            $arr['coupon'] = $subscription->getCoupon();
        }

        if (null !== $subscription->getTaxPercent()) {
            $arr['tax_percent'] = $subscription->getTaxPercent();
        }

        if (null !== $subscription->getTrialEnd() && $subscription->getTrialEnd() instanceof \DateTime) {
            $arr['trial_end'] = $subscription->getTrialEnd()->getTimestamp();
        }

        $customer->subscriptions->create($arr);

        $user->setPlan($this->getPlan($subscription->getPlan()));
        $this->em->persist($user);
        $this->em->flush();

        return $user;
    }

    /**
     * @param User $user
     * @param Subscription $subscription
     * @return User
     */
    public function putSubscription(User $user, Subscription $subscription)
    {
        $newPlan = $this->getPlan($subscription->getPlan());
        $currentPlan = $user->getPlan();

        // If the user does not have a current plan, downgrade is false
        $isDowngrade = ($currentPlan) ?
            $newPlan->getAcl() < $currentPlan->getAcl() :
            false;

        // Retrieve and update the stripe subscription
        Stripe\Stripe::setApiKey($this->stripePrivateKey);

        $customer = Stripe\Customer::retrieve($user->getStripeId());
        $subscriptionData = $customer->subscriptions->data;

        if (!count($subscriptionData)) {
            return $this->postSubscription($user, $subscription);
        }

        $subscriptionId = $subscriptionData[0]->id;
        $s = Stripe\Subscription::retrieve($subscriptionId);

        $s->plan = $subscription->getPlan();
        $s->quantity = $this->getSubscriptionQuantity($subscription);
        if (null !== $subscription->getCoupon()) {
            $s->coupon = $subscription->getCoupon();
        }
        if (null !== $subscription->getTaxPercent()) {
            $s->tax_percent = $subscription->getTaxPercent();
        }

        //  Downgrades are never prorated.
        if ($isDowngrade) {
            $s->prorate = false;
        } else {
            $s->prorate = (null == $subscription->getProrate()) ? true : $subscription->getProrate();
        }

        if (null !== $subscription->getTrialEnd() && $subscription->getTrialEnd() instanceof \DateTime) {
            $s->trial_end = $subscription->getTrialEnd()->getTimestamp();
        }
        if (null != $subscription->getProrationDate() && $subscription->getProrationDate() instanceof \DateTime) {
            $s->proration_date = $subscription->getProrationDate()->getTimestamp();
        }

        $s->save();

        // Update the user object
        $user->setPlan($newPlan);
        $this->em->persist($user);
        $this->em->flush();

        return $user;
    }

    /**
     * @param User $user
     * @return User
     */
    public function cancelUserSubscription(User $user)
    {
        Stripe\Stripe::setApiKey($this->stripePrivateKey);

        $customer = $this->getCustomer($user);

        if ($customer && count($customer->subscriptions->data)) {
            $subscriptionId = $customer->subscriptions->data[0]->id;
            $subscription = Stripe\Subscription::retrieve($subscriptionId);

            $subscription->cancel();
        }

        return $user;
    }

    /**
     * @param User $user
     * @return \Stripe\Customer
     */
    public function getCustomer(User $user)
    {
        Stripe\Stripe::setApiKey($this->stripePrivateKey);

        return (null !== $user->getStripeId()) ? Stripe\Customer::retrieve($user->getStripeId()) : null;
    }

    /**
     * @param $plan
     * @return \AppBundle\Entity\Stripe\Plan|null|object
     */
    private function getPlan($plan)
    {
        return $this->em->getRepository(Plan::class)->findOneBy(['stripe_plan_id' => $plan]);
    }

    /**
     * @param Source $source
     * @return array
     */
    private function getSourceFromObject(Source $source)
    {
        return [
            'object' => $source->getObject(),
            'number' => $source->getNumber(),
            'cvc' => $source->getCvc(),
            'exp_month' => $source->getExpMonth(),
            'exp_year' => $source->getExpYear(),
            'name' => $source->getName(),
            'address_line1' => $source->getAddressLine1(),
            'address_line2' => $source->getAddressLine2(),
            'address_city' => $source->getAddressCity(),
            'address_state' => $source->getAddressState(),
            'address_zip' => $source->getAddressZip()
        ];
    }

    /**
     * @param Subscription $subscription
     * @return int
     *
     * Enterprise subscriptions have a minimum of 4 users
     */
    private function getSubscriptionQuantity(Subscription $subscription)
    {
        $plan = $this->getPlan($subscription->getPlan());

        // Enterprise plans have a minimum of 4 users
        if ($plan && $plan->getAcl() == FeatureAccessLevel::ENTERPRISE) {
            if ($subscription->getQuantity() < 4) {
                return 4;
            }
        }

        return $subscription->getQuantity();
    }
}
