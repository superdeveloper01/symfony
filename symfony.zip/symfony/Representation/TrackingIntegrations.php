<?php

namespace AppBundle\Representation;

use JMS\Serializer\Annotation as Serializer;
use Pagerfanta\Adapter\ArrayAdapter;
use Pagerfanta\Pagerfanta;

/** @Serializer\XmlRoot("tracking-integrations") */
class TrackingIntegrations implements RepresentationInterface
{
    /**
     * @Serializer\XmlKeyValuePairs
     */
    public $meta;

    /**
     * @Serializer\Type("array<AppBundle\Entity\TrackingIntegration>")
     * @Serializer\XmlList(inline=true, entry = "integration")
     * @Serializer\SerializedName("tracking-integrations")
     */
    public $data;

    public function __construct($query, $total)
    {
        $pager = new Pagerfanta(new ArrayAdapter($query));

        $this->addMeta('current_items', $pager->getNbResults());
        $this->addMeta('total_items', (int) $total);

        $this->data = $pager;
    }

    public function addMeta($key, $value)
    {
        $this->meta[$key] = $value;
    }

    public function getData()
    {
        return $this->data;
    }

    public function getMeta($key)
    {
        return $this->meta[$key];
    }
}