<?php

namespace AppBundle\Representation;

use JMS\Serializer\Annotation as Serializer;
use Pagerfanta\Adapter\ArrayAdapter;
use Pagerfanta\Pagerfanta;

/** @Serializer\XmlRoot("endorsements") */
class PublicEndorsements implements RepresentationInterface
{
    /**
     * @Serializer\XmlKeyValuePairs
     */
    public $meta;

    /**
     * @Serializer\Type("array<AppBundle\Entity\PublicEndorsement>")
     * @Serializer\XmlList(inline=true, entry="endorsements")
     * @Serializer\SerializedName("endorsements")
     */
    public $data;

    public function __construct($averageRating, $results, $total, $page, $limit = 500)
    {
        if ($limit > 500) {
            $limit = 500;
        }

        $pager = new Pagerfanta(new ArrayAdapter($results));
        $pager->setMaxPerPage((int) $limit);
        $pager->setCurrentPage($page);

        $this->addMeta('limit', $pager->getMaxPerPage());
        $this->addMeta('page', (int) $page);
        $this->addMeta('total_endorsements', (int) $total);
        $this->addMeta('average_rating', $averageRating);

        $this->data = array_values($pager->getCurrentPageResults());
    }

    public function addMeta($key, $value)
    {
        $this->meta[$key] = $value;
    }

    public function getData()
    {
        return $this->data;
    }

    public function getMeta($key)
    {
        return $this->meta[$key];
    }
}