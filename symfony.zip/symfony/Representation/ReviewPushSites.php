<?php

namespace AppBundle\Representation;

use JMS\Serializer\Annotation as Serializer;
use Pagerfanta\Adapter\ArrayAdapter;
use Pagerfanta\Pagerfanta;

/** @Serializer\XmlRoot("review_push_sites") */
class ReviewPushSites implements RepresentationInterface
{
    /**
     * @Serializer\XmlKeyValuePairs
     */
    public $meta;

    /**
     * @Serializer\Type("array<AppBundle\Document\Sharing\ReviewPushSite>")
     * @Serializer\XmlList(inline=true, entry="ReviewPushSite")
     * @Serializer\SerializedName("review_push_sites")
     */
    public $data;

    public function __construct($results, $total, $limit = 100, $offset = 1)
    {
        if ($limit > 250) {
            $limit = 250;
        }

        $pager = new Pagerfanta(new ArrayAdapter($results));
        $pager->setMaxPerPage((int) $limit);
        $pager->setCurrentPage(ceil($offset/$limit));

        $this->addMeta('limit', $pager->getMaxPerPage());
        $this->addMeta('offset', $pager->getCurrentPageOffsetStart());
        $this->addMeta('current_items', $pager->getNbResults());
        $this->addMeta('total_items', (int) $total);

        $this->data = array_values($pager->getCurrentPageResults());
    }

    public function addMeta($key, $value)
    {
        $this->meta[$key] = $value;
    }

    public function getData()
    {
        return $this->data;
    }

    public function getMeta($key)
    {
        return $this->meta[$key];
    }
}