<?php

namespace AppBundle\Command;

use AppBundle\Migration\CSVParser;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class SurveyRedirectCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('app:generatesurveyredirects')
            ->setDescription('Generates redirects from old survey url pattern to new survey pattern');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $csvParser = new CSVParser();
        $candidates = $csvParser->parse([
            fopen(__DIR__ . '/../../../data/migration/guardian-survey-redirects.csv', 'r'),
        ]);

        $output->writeln('Initializing...');
        $output->writeln(sprintf('%d primary accounts have been selected', sizeof($candidates)));

        $surveyMigrator = $this->getContainer()->get('survey_migrator');

        $file = fopen(__DIR__ . '/../../../data/redirects/survey-redirects.txt', 'w+');

        foreach ($candidates as $candidate) {
            $redirects = $surveyMigrator->generateSurveyRedirects($candidate);

            foreach ($redirects as $redirect) {
                fwrite($file, $redirect . "\n");
            }

            $this->getContainer()->get('doctrine.orm.entity_manager')->clear();
        }

        print("Completo");
    }
}
