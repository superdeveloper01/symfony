<?php

namespace AppBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class SlugMigratorCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('app:migrateslugs')
            ->setDescription('Updates database slugs for users and generates a redirect statement');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $candidates = [];
        $handle = fopen(__DIR__ . '/../../../data/migration/mass-slug-change.csv', "r");

        while (($data = fgetcsv($handle, 100, ",")) !== false) {
            $candidates[] = $data;
        }

        $output->writeln('Initializing...');
        $output->writeln(sprintf('%d users have been loaded', sizeof($candidates)));

        $slugMigrator = $this->getContainer()->get('slug_migrator');

        $file = fopen(__DIR__ . '/../../../data/redirects/slug-redirects.txt', 'w+');

        foreach ($candidates as $candidate) {
            $redirect = $slugMigrator->migrateSlug($candidate[0]);
            fwrite($file, $redirect . "\n");
        }

        $output->writeln("Completo");
    }
}
