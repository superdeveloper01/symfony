<?php

namespace AppBundle\Command;

use AppBundle\Document\EndorsementRequest;
use AppBundle\Document\EndorsementResponse;
use AppBundle\Entity\Survey;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class MarkResponseSharedCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('eendorsements:markresponseshared')
            ->setDescription('Mark endorsement responses as shared on social media for a specific user')
            ->addArgument('userId', InputArgument::REQUIRED);
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        ini_set('max_execution_time', 0); // Let it rip!

        $container = $this->getContainer();
        if ($container->getParameter('crons_enabled') == "true") {
            $userId = strtolower($input->getArgument('userId'));

            $em = $container->get('doctrine.orm.default_entity_manager');

            // Find the user's surveys
            $surveys = $em->getRepository(Survey::class)->findBy(['user' => $userId]);

            if (count($surveys)) {
                $dm = $container->get('doctrine.odm.mongodb.document_manager');
                $endorsementRequestRepo = $dm->getRepository(EndorsementRequest::class);
                $endorsementResponseRepo = $dm->getRepository(EndorsementResponse::class);
                $date = new \DateTime;

                /** For each survey, find requests and responses and mark as shared */
                /** @var Survey $survey */
                foreach ($surveys as $survey) {
                    $endorsementRequests = $endorsementRequestRepo->findBy(['survey_id' => $survey->getId()]);

                    /** @var EndorsementRequest $endorsementRequest */
                    foreach ($endorsementRequests as $endorsementRequest) {
                        /** @var EndorsementResponse $endorsementResponse */
                        $endorsementResponse = $endorsementResponseRepo
                            ->findOneBy(['endorsement_request.id' => $endorsementRequest->getId()]);

                        if ($endorsementResponse) {
                            $shared = $endorsementResponse->getShared();

                            $shared['user_facebook'] = $date->format('Y-m-d H:i:s') . ' NO UPDATE KEY';
                            $shared['user_twitter'] = $date->format('Y-m-d H:i:s') . ' NO UPDATE KEY';
                            $shared['user_linkedin'] = $date->format('Y-m-d H:i:s') . ' NO UPDATE KEY';
                            $shared['branch_facebook'] = $date->format('Y-m-d H:i:s') . ' NO UPDATE KEY';
                            $shared['branch_twitter'] = $date->format('Y-m-d H:i:s') . ' NO UPDATE KEY';
                            $shared['branch_linkedin'] = $date->format('Y-m-d H:i:s') . ' NO UPDATE KEY';
                            $shared['company_facebook'] = $date->format('Y-m-d H:i:s') . ' NO UPDATE KEY';
                            $shared['company_twitter'] = $date->format('Y-m-d H:i:s') . ' NO UPDATE KEY';
                            $shared['company_linkedin'] = $date->format('Y-m-d H:i:s') . ' NO UPDATE KEY';

                            $endorsementResponse->setShared($shared);

                            $dm->persist($endorsementResponse);
                        }
                    }

                    $dm->flush();
                }
            }
        }
    }
}
