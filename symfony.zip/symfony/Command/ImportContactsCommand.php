<?php

namespace AppBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class ImportContactsCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('eendorsements:importcontacts')
            ->setDescription('Import contacts, assign to users, send endorsement requests')
            ->addArgument(
                'sendEndorsementRequests',
                InputArgument::OPTIONAL,
                'Boolean flag indicated whether to create endorsement requests for contacts'
            );
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        ini_set('max_execution_time', 0); // Let it rip!

        $candidates = [];
        $handle = fopen(__DIR__ . '/../../../data/imports/contacts.csv', "r");

        while (($data = fgetcsv($handle, 100, ",")) !== false) {
            $candidates[] = $data;
        }

        $output->writeln('Initializing...');
        $output->writeln(sprintf('%d contacts have been loaded', sizeof($candidates)));

        $sendEndorsements = $input->getArgument('sendEndorsementRequests');
        $response = $this->getContainer()->get('contact_service')->assignAndImportContacts(
            $candidates,
            'true' == $sendEndorsements ? true : false
        );

        $output->writeln(sprintf('%d valid contacts have been persisted', sizeof($response->contacts)));

        foreach ($response->errors as $error) {
            $output->writeln($error);
        }
    }
}
