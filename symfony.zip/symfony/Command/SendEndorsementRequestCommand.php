<?php

namespace AppBundle\Command;

use AppBundle\Document\EndorsementRequest;
use AppBundle\Document\EndorsementRequestRepository;
use AppBundle\Document\Statistic\EndorsementResponseReceived;
use AppBundle\Entity\Survey;
use AppBundle\Entity\SurveyPushUrl;
use Doctrine\ODM\MongoDB\DocumentManager;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class SendEndorsementRequestCommand
 * @package AppBundle\Command
 */
class SendEndorsementRequestCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('eendorsements:sendendorsementrequests')
            ->setDescription('Send endorsement requests');
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|void|null
     * @throws \Exception
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $container = $this->getContainer();

        if ($container->getParameter('crons_enabled') == "true") {
            /** @var DocumentManager $dm */
            $dm = $container->get('doctrine_mongodb')->getManager();

            /** @var EndorsementRequestRepository $repo */
            $repo = $dm->getRepository(EndorsementRequest::class);

            /** @var array $endorsementRequests */
            $endorsementRequests = $repo->getUnsentRequests(200);

            if (count($endorsementRequests)) {
                $em = $container->get('doctrine')->getManager();
                $surveyRepo = $em->getRepository(Survey::class);

                /** @var EndorsementRequest $endorsementRequest */
                foreach ($endorsementRequests as $endorsementRequest) {
                    /** @var Survey $survey */
                    $survey = $surveyRepo->findOneBy([
                        'id' => $endorsementRequest->getSurveyId(),
                        'active' => true,
                    ]);

                    if ($survey) {
                        $result = $this->deliver($survey, $endorsementRequest);

                        if ($result) {
                            $endorsementRequest->setSent(new \DateTime);
                            $dm->persist($endorsementRequest);

                            $container->get('statistic_service')->recordEndorsementRequestSent($survey->getUser());
                        }
                    }
                }

                $dm->flush();
            }

            $date = new \DateTime();
            $output->writeln($date->format('m/d/Y g:ia') . ': Endorsement Requests Processed: ' .
                count($endorsementRequests));
        }
    }

    /**
     * @param Survey $survey
     * @param EndorsementRequest $endorsementRequest
     * @return bool|int
     *
     * If endorsement request preference is to deliver via text, attempt that first.
     * If unsuccessful, fall back to delivery via e-mail
     */
    private function deliver(Survey $survey, EndorsementRequest $endorsementRequest)
    {
        if (EndorsementRequest::DELIVERY_PREFERENCE_TEXT === $endorsementRequest->getDeliveryPreference()) {
            $result = $this->deliverViaText($survey, $endorsementRequest);

            if ($result) {
                return $result;
            }
        }

        return $this->deliverViaEmail($survey, $endorsementRequest);
    }

    /**
     * @param Survey $survey
     * @param EndorsementRequest $endorsementRequest
     * @return bool
     */
    private function deliverViaText(Survey $survey, EndorsementRequest $endorsementRequest)
    {
        if (!$endorsementRequest->getRecipientPhone()) {
            return false;
        }

        $container = $this->getContainer();

        $link = $container->get('survey_service')->getSurveyLink($survey, $endorsementRequest);

        switch ($survey->getType()) {
            case Survey::SURVEY_TYPE_REVIEW_PUSH:
                $message = $survey->getSurveyMessage();
                /** @var SurveyPushUrl $pushUrl */
                foreach ($link as $pushUrl) {
                    if (null !== $pushUrl->getType()) {
                        $message .= "\n" . $pushUrl->getType();
                    }
                    $shortLink = $container->get('bitly_service')->shorten($pushUrl->getUrl());

                    $l = $shortLink ? $shortLink->link : $pushUrl->getUrl();

                    $message .= "\n" . $l . "\n";
                }
                break;
            default:
                $shortLink = $container->get('bitly_service')->shorten($link);

                if ($shortLink) {
                    $link = $shortLink->link;
                }

                $message = $survey->getSurveyMessage() . "\n" . $link;
        }

        return $container->get('twilio_service')->sendText(
            $endorsementRequest->getRecipientPhone(),
            $message,
            $endorsementRequest->getId()
        );
    }

    /**
     * @param Survey $survey
     * @param EndorsementRequest $endorsementRequest
     * @return int
     */
    private function deliverViaEmail(Survey $survey, EndorsementRequest $endorsementRequest)
    {
        $container = $this->getContainer();

        switch ($survey->getType()) {
            case Survey::SURVEY_TYPE_REVIEW_PUSH:
                $user = $survey->getUser();
                $averageScore = $container->get('statistic_service')->calculateAverageScoreByUser($user);

                $result = $container->get('mailer')->sendEndorsementRequestToRecipient(
                    $survey,
                    $endorsementRequest,
                    $container->get('survey_service')->getSurveyLink($survey, $endorsementRequest),
                    $container->get('survey_service')->getFeedbackLink($survey, $endorsementRequest),
                    $container->get('statistic_service')->countUserStats(
                        $user,
                        EndorsementResponseReceived::class
                    ),
                    number_format((($averageScore * 100) / 20), 1)
                );
                break;
            case Survey::SURVEY_TYPE_VIDEOMONIAL:
                $user = $survey->getUser();
                $averageScore = $container->get('statistic_service')->calculateAverageScoreByUser($user);

                $result = $container->get('mailer')->sendEndorsementRequestToRecipient(
                    $survey,
                    $endorsementRequest,
                    $container->get('survey_service')->getSurveyLink($survey, $endorsementRequest),
                    null,
                    $container->get('statistic_service')->countUserStats(
                        $user,
                        EndorsementResponseReceived::class
                    ),
                    number_format((($averageScore * 100) / 20), 1)
                );
                break;
            default:
                $result = $container->get('mailer')->sendEndorsementRequestToRecipient(
                    $survey,
                    $endorsementRequest,
                    $container->get('survey_service')->getSurveyLink($survey, $endorsementRequest)
                );
        }

        return $result;
    }
}
