<?php

namespace AppBundle\Command;

use AppBundle\Enumeration\Broadcaster;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class BroadcastCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('eendorsements:broadcast')
            ->setDescription('Broadcast endorsements')
            ->addArgument('broadcaster', InputArgument::REQUIRED);
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        ini_set('max_execution_time', 0); // Let it rip!

        $container = $this->getContainer();
        if ($container->getParameter('crons_enabled') == "true") {
            $platform = strtolower($input->getArgument('broadcaster'));

            switch ($platform) {
                case Broadcaster::TWITTER:
                    $container->get('broadcast_manager_twitter')->broadcast();
                    break;
                case Broadcaster::LINKEDIN:
                    $container->get('broadcast_manager_linkedin')->broadcast();
                    break;
                case Broadcaster::FACEBOOK:
                    $container->get('broadcast_manager_facebook')->broadcast();
                    break;
            }


            $date = new \DateTime();
            $output->writeln($date->format('m/d/Y g:ia') . ': Broadcast executed');
        }
    }
}
