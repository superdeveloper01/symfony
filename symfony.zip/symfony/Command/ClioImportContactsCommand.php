<?php

namespace AppBundle\Command;

use AppBundle\Entity\ClioToken;
use AppBundle\Entity\ClioUser;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class ClioImportContactsCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('eendorsements:importcliocontacts')
            ->setDescription('Import contacts from Clio');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        ini_set('max_execution_time', 0); // Let it rip!

        $container = $this->getContainer();

        if ($container->getParameter('crons_enabled') == "true") {

            $clioService = $container->get('clio_service');
            $contactService = $container->get('contact_service');
            $em = $container->get('doctrine.orm.entity_manager');
            $yesterday = new \DateTime('yesterday');
            $since = $yesterday->format(\DateTime::ATOM);

            // Get integrated users
            $clioTokens = $em->getRepository(ClioToken::class)->findAll();

            /** @var ClioToken $clioToken */
            foreach ($clioTokens as $clioToken) {

                // Get closed matters
                $matters = $clioService->getClosedMatters($clioToken, $since);

                if (!empty($matters['data'])) {
                    foreach ($matters['data'] as $matter) {

                        $clioUser = $matter['user'];
                        $client = $appointment['client'];

                        // If Clio user is mapped with the endorsement users
                        $mappedUser = $clioService->getMappedUser($clioToken, $clioUser['id']);
                        if($mappedUser){
                            $user = $mappedUser->getUser();

                            // Add clio user as eEndorsement contact
                            $contactService->createContactFromClioAccount(
                                $client,
                                $user
                            );
                        }
                    }
                }
            }
        }
    }

    /**
     * @param Array $patient
     * @return Array $contact
     */
    private function parsePatientInfo($patient) {

        // Filter out minors
        if(!empty($patient['date_of_birth']) && (strtotime($patient['date_of_birth']) > strtotime("-18 years"))) {
            return false;
        }
        if(empty($patient['email'])) {
            return false;
        }

        $contact = [];
        $contact['firstname'] = $patient['first_name'];
        $contact['lastname'] = $patient['last_name'];
        $contact['email'] = $patient['email'];
        $contact['phone'] = (!empty($patient['home_phone'])) ? $patient['home_phone'] : $patient['cell_phone'];
        $contact['city'] = $patient['city'];
        $contact['state'] = $patient['state'];

        return $contact;
    }
}
