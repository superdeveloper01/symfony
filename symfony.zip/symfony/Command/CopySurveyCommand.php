<?php

namespace AppBundle\Command;

use AppBundle\Entity\Survey;
use AppBundle\Entity\User;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class CopySurveyCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('eendorsements:copy_survey')
            ->setDescription('Copy survey to all users in a company')
            ->addArgument('survey_id', InputArgument::REQUIRED)
            ->addArgument('set_as_default', InputArgument::REQUIRED)
            ->addArgument('user_id', InputArgument::OPTIONAL);
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        ini_set('max_execution_time', 0); // Let it rip!

        $surveyId = strtolower($input->getArgument('survey_id'));
        /** @var Survey $survey */
        $survey = $this->getContainer()->get('doctrine.orm.entity_manager')
            ->getRepository(Survey::class)->find($surveyId);

        $setAsDefault = strtolower($input->getArgument('set_as_default'));
        $setAsDefault = "true" == $setAsDefault ? true : false;

        $userId = strtolower($input->getArgument('user_id'));

        if (empty($userId)) {
            $this->getContainer()->get('survey_service')->copySurveyToAllUsers($survey, $setAsDefault);
        } else {
            /** @var User $user */
            $user = $this->getContainer()->get('doctrine.orm.entity_manager')
                ->getRepository(User::class)->find($userId);

            if ($user) {
                $this->getContainer()->get('survey_service')->copySurveyToUser($survey, $user, $setAsDefault);
            }
        }

        $date = new \DateTime();
        $output->writeln($date->format('m/d/Y g:ia') . ': Survey Copied');
    }
}
