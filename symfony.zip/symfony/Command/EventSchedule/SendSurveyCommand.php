<?php

namespace AppBundle\Command\EventSchedule;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class SendSurveyCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('eendorsements:eventschedule:sendsurvey')
            ->setDescription('Queue endorsement requests for scheduled send survey events');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        ini_set('max_execution_time', 0); // Let it rip!

        if ($this->getContainer()->getParameter('crons_enabled') == "true") {
            $this->getContainer()->get('scheduled_event_send_survey_service')->execute();
        }
    }
}
