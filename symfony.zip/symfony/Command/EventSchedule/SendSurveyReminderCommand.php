<?php

namespace AppBundle\Command\EventSchedule;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class SendSurveyReminderCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('eendorsements:eventschedule:sendsurveyreminder')
            ->setDescription('Send survey reminders via e-mail');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        ini_set('max_execution_time', 0); // Let it rip!

        if ($this->getContainer()->getParameter('crons_enabled') == "true") {
            $this->getContainer()->get('scheduled_event_send_survey_reminder_service')->execute();
        }
    }
}
