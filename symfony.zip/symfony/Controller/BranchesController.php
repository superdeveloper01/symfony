<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Branch;
use AppBundle\Representation\Branches;
use FOS\RestBundle\Controller\Annotations as Rest;
use FOS\RestBundle\Controller\FOSRestController;
use FOS\RestBundle\Request\ParamFetcherInterface;
use JMS\Serializer\SerializationContext;
use Nelmio\ApiDocBundle\Annotation as Doc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;

/** @Route("/branches") */
class BranchesController extends FOSRestController
{
    /**
     * @Rest\Get("", name="branches_get")
     *
     * @Rest\QueryParam(
     *      name="filter",
     *      nullable=true,
     *      description="Filter"
     * )
     * @Rest\QueryParam(
     *      name="order_by",
     *      description="Order by"
     * )
     * @Rest\QueryParam(
     *      name="order_direction",
     *      default="ASC",
     *      description="Order direction (ascending or descending)"
     * )
     * @Rest\QueryParam(
     *      name="limit",
     *      requirements="\d+",
     *      default="25",
     *      description="Max number of results"
     * )
     * @Rest\QueryParam(
     *      name="page",
     *      requirements="\d+",
     *      default="1",
     *      description="The pagination offset"
     * )
     *
     * @Rest\QueryParam(
     *      name="active",
     *      requirements="active|inactive|all",
     *      default="all",
     *      description="Return active, inactive or all records"
     * )
     *
     * @Doc\ApiDoc(
     *      section="Branch",
     *      description="Retrieve Branches",
     *      https="true",
     *      statusCodes={
     *         200 = "Returned when successful",
     *         401 = "Unauthorized",
     *         404 = "Returned when records are not found"
     *     }
     * )
     */
    public function getAction(ParamFetcherInterface $paramFetcher)
    {
        ini_set('memory_limit', '1024M'); // Boost the memory for companies with large number of branches

        $filter = $paramFetcher->get('filter');
        $orderBy = $paramFetcher->get('order_by');
        $orderDirection = $paramFetcher->get('order_direction');
        if (empty($orderDirection) || strtoupper($orderDirection) != 'DESC') {
            $orderDirection = 'ASC';
        }
        $limit = (empty($paramFetcher->get('limit'))) ? 25 : $paramFetcher->get('limit');
        $page = (empty($paramFetcher->get('page'))) ? 1 : $paramFetcher->get('page');
        $active = strtolower($paramFetcher->get('active'));
        $company = ($this->get('security.authorization_checker')->isGranted('ROLE_ADMIN')) ?
            null : $this->getUser()->getBranch()->getCompany();

        $repo = $this->getDoctrine()->getRepository(Branch::class);
        $query = $repo->filter($filter, $orderBy, $orderDirection, $active, $company);

        $branches = new Branches($query, $repo->getCount(), $limit, $page);

        $response = [];
        $response['meta'] = $branches->meta;

        $data = [];
        foreach ($branches->data as $item) {
            $context = new SerializationContext();
            $context->setGroups("private");
            $data[] = json_decode($this->get('jms_serializer')->serialize($item, 'json', $context), true);
        }

        $response['branches'] = $data;


        return $this->view($response, Response::HTTP_OK);
    }
}
