<?php

namespace AppBundle\Controller;

use AppBundle\Entity\BranchProfile;
use AppBundle\Exception\ApiProblemException;
use AppBundle\Model\ApiProblem;
use FOS\RestBundle\Controller\Annotations as Rest;
use FOS\RestBundle\Controller\FOSRestController;
use Nelmio\ApiDocBundle\Annotation as Doc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Validator\ConstraintViolationListInterface;

/** @Route("/branch-profile") */
class BranchProfileController extends FOSRestController
{
    /**
     * @Rest\Get(path="/{slug}", name="branch_profile_get")
     *
     * @Rest\View(serializerGroups={"public", "profile"})
     *
     * @ParamConverter(
     *     "slug",
     *     class="AppBundle\Entity\BranchProfile",
     *     options={
     *          "repository_method" = "getProfileByBranchSlug",
     *          "mapping" = {"slug": "slug"},
     *          "map_method_signature" = true
     *     }
     * )
     *
     * @Doc\ApiDoc(
     *      section="Profile",
     *      description="Get branch profile",
     *      https="true",
     *      statusCodes={
     *         200="Success",
     *         404="Resource not found"
     *     }
     * )
     */
    public function getAction(BranchProfile $slug)
    {
        /** Add social media sites to response */
        $profileService = $this->get('profile_service');

        return $this->view(
            $profileService->serializeBranchProfile($slug, true, ['public', 'profile']),
            Response::HTTP_OK
        );
    }

    /**
     * @Rest\Put(path="/{id}", name="branch_profile_put")
     *
     * @Rest\View(serializerGroups={"public", "profile"})
     *
     * @ParamConverter(
     *      "profile",
     *      converter="fos_rest.request_body",
     *      options={
     *          "validator"={
     *              "groups"="branch_profile_put"
     *          }
     *      }
     * )
     *
     * @Doc\ApiDoc(
     *      section="Profile",
     *      description="Update a branch profile",
     *      https="true",
     *      statusCodes={
     *         200="Profile Updated",
     *         400="Invalid data"
     *     }
     * )
     *
     */
    public function putAction(BranchProfile $id, BranchProfile $profile, ConstraintViolationListInterface $violations)
    {
        $this->denyAccessUnlessGranted('edit', $profile);

        if (count($violations)) {
            throw new ApiProblemException(
                new ApiProblem(Response::HTTP_BAD_REQUEST, $violations, ApiProblem::TYPE_VALIDATION_ERROR)
            );
        }

        $profileService = $this->get('profile_service');

        $profile = $profileService->updateBranchProfile($id, $profile);

        return $this->view(
            $profileService->serializeBranchProfile($profile, true, ['public', 'profile']),
            Response::HTTP_OK
        );
    }

    /**
     * @Rest\Post(path="", name="branch_profile_post")
     *
     * @Rest\View(serializerGroups={"public", "profile"})
     *
     * @ParamConverter(
     *      "profile",
     *      converter="fos_rest.request_body",
     *      options={
     *          "validator"={
     *              "groups"="branch_profile_post"
     *          }
     *      }
     * )
     *
     * @Doc\ApiDoc(
     *      section="Profile",
     *      description="Create a branch profile",
     *      https="true",
     *      statusCodes={
     *         201="Profile Created",
     *         400="Invalid data"
     *     }
     * )
     *
     */
    public function postAction(BranchProfile $profile, ConstraintViolationListInterface $violations)
    {
        $this->denyAccessUnlessGranted('edit', $profile);

        if (count($violations)) {
            throw new ApiProblemException(
                new ApiProblem(Response::HTTP_BAD_REQUEST, $violations, ApiProblem::TYPE_VALIDATION_ERROR)
            );
        }

        $em = $this->getDoctrine()->getManager();
        $repo = $em->getRepository('AppBundle:BranchProfile');
        $q = $repo->findOneBy(['branch' => $profile->getBranch()->getId()]);
        if ($q) {
            return $this->forward('AppBundle:BranchProfile:put', ['id' => $q->getId()]);
        }

        $profileService = $this->get('profile_service');
        $profile = $profileService->postBranchProfile($profile);

        return $this->view(
            $profileService->serializeBranchProfile($profile, true, ['public', 'profile']),
            Response::HTTP_CREATED
        );
    }

    /**
     * @Rest\Post(path="/{id}/pageview", name="branch_profile_pageview_post")
     *
     * @Doc\ApiDoc(
     *      section="Profile",
     *      description="Create a branch profile pageview",
     *      https="true",
     *      statusCodes={
     *         201="Profile Pageview Created",
     *         404="Profile Not Found"
     *     }
     * )
     *
     */
    public function postPageViewAction(BranchProfile $id)
    {
        $this->get('statistic_service')->recordBranchProfilePageView($id->getBranch());

        return $this->view([], Response::HTTP_CREATED);
    }

    /**
     * @Rest\Post(path="/{id}/survey-link-click", name="branch_profile_surveylinkclick_post")
     *
     * @Doc\ApiDoc(
     *      section="Profile",
     *      description="Record a branch profile survey link click",
     *      https="true",
     *      statusCodes={
     *         201="Profile Survey Link Click Created",
     *         404="Profile not found"
     *     }
     * )
     *
     */
    public function postSurveyLinkClickAction(BranchProfile $id)
    {
        $this->get('statistic_service')->recordBranchProfileSurveyLinkClick($id->getBranch());

        return $this->view([], Response::HTTP_CREATED);
    }
}
