<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Industry;
use AppBundle\Exception\ApiProblemException;
use AppBundle\Model\ApiProblem;
use FOS\RestBundle\Controller\Annotations as Rest;
use FOS\RestBundle\Controller\FOSRestController;
use Nelmio\ApiDocBundle\Annotation as Doc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Validator\ConstraintViolationListInterface;

/**
 * Class IndustryController
 * @package AppBundle\Controller
 *
 * @Route("/industry")
 */
class IndustryController extends FOSRestController
{
    /**
     * @Rest\Get("/{id}", name="industry_get", requirements={"id": "\d+"})
     *
     * @Rest\View(serializerGroups={"default"})
     *
     * @Doc\ApiDoc(
     *      section="Industry",
     *      description="Get industry",
     *      https="true",
     *      statusCodes={
     *         200="Success",
     *         401="Unauthorized",
     *         404="Resource not found"
     *     }
     * )
     */
    public function getAction(Industry $id)
    {
        return $id;
    }

    /**
     * @Rest\Put("/{id}", name="industry_put", requirements={"id": "\d+"})
     *
     * @Rest\View(serializerGroups={"default"})
     *
     * @ParamConverter(
     *      "industry",
     *      converter="fos_rest.request_body",
     *      options={
     *          "validator"={
     *              "groups"="put"
     *          }
     *      }
     * )
     *
     * @Doc\ApiDoc(
     *      section="Industry",
     *      description="Put industry",
     *      https="true",
     *      statusCodes={
     *         200="Success",
     *         401="Unauthorized",
     *         404="Resource not found"
     *     }
     * )
     */
    public function putAction(Industry $id, Industry $industry, ConstraintViolationListInterface $violations)
    {
        if (count($violations)) {
            throw new ApiProblemException(
                new ApiProblem(Response::HTTP_BAD_REQUEST, $violations, ApiProblem::TYPE_VALIDATION_ERROR)
            );
        }
        
        return $this->get('industry_service')->updateIndustry($id, $industry);
    }

    /**
     * @Rest\Post(path="", name="industry_post")
     *
     * @Rest\View(serializerGroups={"default"})
     *
     * @ParamConverter(
     *      "industry",
     *      converter="fos_rest.request_body",
     *      options={
     *          "validator"={
     *              "groups"="post"
     *          }
     *      }
     * )
     *
     * @Doc\ApiDoc(
     *      section="Industry",
     *      description="Create an industry",
     *      https="true",
     *      statusCodes={
     *         201="Success",
     *         400="Invalid data"
     *     }
     * )
     */
    public function postAction(Industry $industry, ConstraintViolationListInterface $violations)
    {
        if (count($violations)) {
            throw new ApiProblemException(
                new ApiProblem(Response::HTTP_BAD_REQUEST, $violations, ApiProblem::TYPE_VALIDATION_ERROR)
            );
        }
        
        return $this->get('industry_service')->createIndustry($industry);
    }

    /**
     * @Rest\Delete(path="/{id}", name="industry_delete")
     *
     * @Rest\View(serializerGroups={"default"})
     *
     * @Doc\ApiDoc(
     *      section="Industry",
     *      description="Delete an industry",
     *      https="true",
     *      statusCodes={
     *         204="Industry deleted",
     *         404="Not found"
     *     }
     * )
     */
    public function deleteAction(Industry $id)
    {
        $em = $this->getDoctrine()->getManager();
        $id->setActive(false);
        $em->persist($id);
        $em->flush();

        $this->get('fos_http_cache.cache_manager')
            ->invalidateRegex('/industries')
            ->invalidateRegex('/industry/' . $id->getId())
            ->flush();

        return $this->view([], Response::HTTP_NO_CONTENT);
    }
}
